#include <iostream>
#include <cmath>

using namespace std;

int main()
{
      
      float numberofdays ;
      float numberofhours;
      float numberofminutes;
      float numberofseconds;
      
      cout << " please enter the number of days : " << endl;
      cin >> numberofdays;
      
      cout << " please enter the number of hours : " << endl;
      cin >> numberofhours;
      
      cout << " please enter the number of minutes : " << endl;
      cin >> numberofminutes;
      
      cout << " please enter the number of seconds : " << endl;
      cin >> numberofseconds;
      
     
      
      cout << ((numberofdays*24*60*60)+(numberofhours*60*60)+(numberofminutes*60)+numberofseconds) << " seconds " << endl;
      
      cout << " the final result = " <<round((numberofdays*24*60*60)+(numberofhours*60*60)+(numberofminutes*60)+numberofseconds)<<endl;
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      

    return 0;
}