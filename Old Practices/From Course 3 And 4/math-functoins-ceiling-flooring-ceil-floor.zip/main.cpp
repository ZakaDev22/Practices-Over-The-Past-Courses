
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
      
         // understand ceil & floor functions 
         
         cout << " ceiling value of 2.9 = " << ceil(2.9) << endl;
         cout << " flooring value of 2.9 = " << floor(2.9) << endl<<endl;
         
         cout << " ceiling value of -2.9 = " << ceil(-2.9) << endl;
         cout << " flooring value of -2.9 = " << floor(-2.9) << endl;
         
         
      
      
      
      
      return 0;
}