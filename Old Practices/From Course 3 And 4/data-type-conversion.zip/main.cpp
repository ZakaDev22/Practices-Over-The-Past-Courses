#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
    
    int num1 ;
    double num2 = 18.99 ;
    
    num1 = num2 ; // implecit conversion from double to int 
    
    num1 = (int) num2 ; // explicit conversion 
    
    num1 = int(num2) ; //explicit conversion
    
    cout << num1 << endl<<endl; 
    
    
    //convert string to integer & float & double 
    
    string str  = "123.456" ;
    
    int num_int = stoi(str) ;
    
    float num_float = stof(str);
    
    double num_double = stod(str);
    
    cout << " num_int : " << num_int << endl;
    cout << " num_float : " << num_float << endl;
    cout << " num_double : " << num_double << endl<<endl;
    
    
    //convert numbers to string 
     
     int num4 = 123 ;
     double num5 = 123.456 ;
     
     string st1 , st2 ;
     
     st1 = to_string(num4) ;
     st2 = to_string(num5) ;
     
    cout << st1 << endl;
    cout << st2 << endl;
    
    
    
    
    
    
    
    
      return 0;
    
}
