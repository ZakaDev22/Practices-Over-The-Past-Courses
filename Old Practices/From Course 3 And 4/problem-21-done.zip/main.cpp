
#include <iostream>

using namespace std;

int main()
{
     float number1; 
     float pi = 3.14 ; 
      
      cout << " please enter the number : " << endl; 
      cin >> number1; 
       
       cout << endl; 
        
        cout << " the area is = " << (number1 * number1)/(4 * pi) << endl;

    return 0;
}