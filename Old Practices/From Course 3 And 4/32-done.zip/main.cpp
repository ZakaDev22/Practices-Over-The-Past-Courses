#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    float number;
    float m ;
    
    cout << " please enter the number : " <<endl;
    cin >> number ;
    
    cout << "please enter the number m : " << endl;
    cin >> m ;
    
    cout << endl;
    
    cout << pow(number,m) << endl;

    return 0;
}