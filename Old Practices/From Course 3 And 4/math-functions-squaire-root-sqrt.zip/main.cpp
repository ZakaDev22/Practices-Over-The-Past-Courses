#include <iostream>
#include <cmath>

using namespace std ;

int main()
 {
        //understand squair root (sqrt)
     
     double  x = 64;
     
     cout << " square root value pf 64 : " << sqrt (x) <<endl;
     
     cout << " square root value of 50 : " << sqrt(50) << endl; 
     
     
     
     return 0;
 }