
#include <iostream>

using namespace std;

int main()
{
     float number1; 
      
      cout << " pleas enter the number : " << endl; 
      cin >> number1 ; 
      
      cout << endl;
       
       cout << " the circle area is = "  << (3.14 *(10*10))/4 << endl;

    return 0;
}