
#include <iostream>

using namespace std;

int main()
{
     string name ; 
     int age ;   
     string city ; 
     string country;
     string monthlysalary;
     float youryearlysalary;
      char gender; 
      bool areyoumarried;
      
       cout<<"pleas enter your name : "<< endl; 
       cin >> name ; 
         
         cout << "pleas enter your age : " <<endl; 
         cin >> age; 
          
          cout << "pleas enter your city : " << endl; 
          cin >> city;  
           
           cout << " pleas enter your country : " << endl; 
           cin >> country; 
            
            cout << " pleas enter your monthly salary : " << endl; 
            cin >> monthlysalary;
             
             cout << " pleas enter your yearly salary : " <<endl; 
             cin >> youryearlysalary ; 
              
              
         cout << " pleas enter your gender : " << endl;  
          cin >> gender;   
           
           cout << " pleas enter are you married ? " <<endl; 
           cin >> areyoumarried;
           
           cout <<endl<<endl;
           
cout << "****************************************"<<endl; 
         cout << " name : " << name << endl; 
         cout << " age : "  << age << endl; 
         cout << " city : " << city << endl; 
         cout << " country : " << country << endl; 
         cout << " monthly salary : " << monthlysalary << endl; 
         cout << " yearly salary : " << youryearlysalary << endl;
         cout << " gender :  " << gender <<endl;  
         cout << " married : " << areyoumarried <<endl;
cout << "******************************************"<<endl;
             
              
               
                 
                  
                  
    return 0;
}
