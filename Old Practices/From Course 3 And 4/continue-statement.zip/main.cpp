#include <iostream>

using namespace std ;


int main()
{
    
    int numbers ;
    
    int sum=0 ;
    
    for (int i=1 ; i<=5 ; i++)
    {
        cout << "please enter the number : " << i << endl;
        cin >> numbers ;
        
        if (numbers>50)
        {
            continue ;
        }
        
        sum+=numbers ;
        
    }
    
    cout << " sum = " << sum << endl; ;
    
    
    return 0;
}