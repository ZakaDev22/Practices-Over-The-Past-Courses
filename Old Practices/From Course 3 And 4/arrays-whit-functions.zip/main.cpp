#include <iostream>
#include <string>

using namespace std ;


void readarraydata(float x[3])
{
     cout << "please enter the first array : " << endl;
     cin >> x[0] ;
     
     cout << " please enter the second array : " << endl;
     cin >> x[1];
     
     cout << "please enter the third array : " << endl;
     cin >> x[2] ;
    
}


float printarraydata( float data[3])
{
    
    return  (data[0]+data[1]+data[2])/3 ;
}



int main()
{
     
      float data[3] ;
    
      readarraydata(data);

     cout << "the average of data[3] = " << printarraydata(data) << endl;
    
    
    return 0;
}