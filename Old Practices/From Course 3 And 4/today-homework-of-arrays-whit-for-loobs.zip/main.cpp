
#include <iostream>

using namespace std;

struct stgrades
{
  string arabic;
  string englesh;
  string islamic;
  string sport ;
  
};

void readpesongrades(stgrades &grades)
{
    cout << "enter your grade  arabic : " <<endl;
    cin >>grades.arabic;
    
    cout << " enter your grade in englesh : " <<endl;
    cin >> grades.englesh ;
    
    cout << "enter your grade in islamic : " <<endl;
    cin >>grades.islamic ;
    
    cout << "enter your grade in sport : " << endl;
    cin >> grades.sport ;
}

void printgrades(stgrades grades)
{
       cout << "\t***************************************************************\n";
       cout << "\t***************************************************************\n";
       cout << "\t***************************************************************\n";
cout <<"\t********\t"<<endl;     
cout <<"\t********\t"<< " grade 1 : arabic  = " << grades.arabic <<" / 100" <<endl;
cout <<"\t********\t"<< " grade 2 : englesh = " << grades.englesh <<" / 100" <<endl;
cout <<"\t********\t"<< " grade 3 : islamic = " << grades.islamic <<" / 100" <<endl;
cout <<"\t********\t"<<" grade 4 : sport   = " << grades.sport <<" / 100" <<endl;
cout <<"\t********\t"<<endl;
       cout << "\t***************************************************************\n";
       cout << "\t***************************************************************\n";
       cout << "\t***************************************************************\n";
       
}

void readpersons(stgrades persons[100] , int &numbersofpersons)
{
    cout << " please enter number of persens : " <<endl;
    cin >> numbersofpersons ;
    
    for (int i=0 ; i<=numbersofpersons-1 ; i++)
    {
        cout << "eprsen list number ["<<i+1<<"] " <<endl;
        readpesongrades(persons[i]);
    }
    
}

void printpersons(stgrades persons[100] , int numbersofpersons)
{
    for (int i=0 ; i<=numbersofpersons-1 ; i++)
    {
        cout << "person list number ["<<i+1<<"] " <<endl;
        printgrades(persons[i]);
    }
    
}

int main()
{
    stgrades persons[100];
    
    int numbersofpersons ;
    
    
    readpersons(persons , numbersofpersons) ;
    
    printpersons(persons , numbersofpersons) ;
    
  

    return 0;
}
