
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
      //understand power functions (pow)
      
      short x = 2 ;
      short y = 4 ;
      
      cout << " power value : x^y = 2^4 = " << pow(x,y)<< endl;
      cout << " power value : x^y = 4^3 = " << pow(4,3) << endl;
      
     

    return 0;
}