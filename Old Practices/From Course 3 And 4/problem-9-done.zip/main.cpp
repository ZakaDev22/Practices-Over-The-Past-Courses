
#include <iostream>

using namespace std;

int main()
{  
     
     
        short int  number1; 
        short int  number2 ; 
        short int  number3 ; 
         
        
        cout << " please enter the first number : " << endl; 
        cin >> number1 ; 
         
         cout << " pleas enter the second number : " << endl; 
         cin >> number2; 
          
          cout << " please enter the third number : " << endl; 
          cin >> number3; 
           
            
         cout << number1 <<endl<<endl; 
         cout << number2 <<endl<<endl; 
         cout << number3 <<endl<<endl;
         
         cout <<endl; 
         
         cout << " the sum is : " << number1 + number2 + number3 <<endl;
             
             
               
               
               
                
                 
                  
                   
       
        
          
          
           
            
            
    return 0;
}