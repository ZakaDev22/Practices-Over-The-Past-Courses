
#include <iostream>

using namespace std;

int main()
{
     float a ; 
     float b ;  
     float pi = 3.14 ;
       
      
      cout << " please enter number a : " << endl; 
      cin >> a ; 
       
      cout << " please enter number b : " << endl; 
      cin >> b ; 
      
       cout << endl; 
       
        cout << " circle area is = " << ( pi * b *b /4) * (( 2 * a - b) / ( 2 * a + b ))  <<endl;
     

    return 0;
}