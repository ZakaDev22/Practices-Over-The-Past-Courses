
#include <iostream>

using namespace std;

int main()
{
    float  penny  ; 
     float  nickel  ; 
    float    dime ; 
    float   quarter   ; 
     float  dollar   ;  
   
      
       
        cout << " please enter pennies : " << endl; 
        cin >> penny ; 
         
        cout << " please enter nickels : " << endl; 
        cin >> nickel ; 
        
        cout << " please enter dimes : " << endl; 
        cin >> dime;  
         
        cout << " please enter quarters : " <<endl;  
        cin >> quarter ; 
         
        cout << " please enter dollors : " << endl ; 
        cin >> dollar; 
         
        cout << endl; 
        
        cout <<  penny*1 + nickel*5 + dime*10 + quarter*25 + dollar*100 << " pennies" << endl; 
        cout <<  (penny*1 + nickel*5 + dime*10 + quarter*25 + dollar*100)/100 << " dollars " <<endl;
          
           
            
            
             
         
          
    return 0;
}