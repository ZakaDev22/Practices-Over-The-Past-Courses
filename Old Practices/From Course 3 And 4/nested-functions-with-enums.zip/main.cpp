#include <iostream>
#include <string>

using namespace std;

enum enweekdays { sun=1 , mon=2 ,thur=3 ,weed=4 , thus=5 , fri=6 , sat=7};

void showweekdaymenuf()
{
cout << "********************************************\n";
            cout << "\t week days menu"<<endl;
cout << "********************************************\n";
     
     cout << " (1) : sunday " << endl;
     cout << " (2) : monday "<<endl;
     cout << " (3) : tursday "<<endl;
     cout << " (4) : wednesday " <<endl;
     cout << " (5) : thusday"<<endl;
     cout << " (6) : friday " <<endl;
     cout << " (7) : saturday " <<endl;
    
 cout <<" **************************************************\n";
               cout << "\t chois your day " << endl;
 cout << "**************************************************\n";
    
}

enweekdays readweekdays()
{
    
    int z ;
    cin >> z ;
    
     return (enweekdays)z ;
    
}

string getweekday(enweekdays weekday)
{
    switch (weekday)
    {
        case enweekdays::sun :
        return "sunday";
        break ;
        
        case enweekdays::mon :
        return "monday";
        break;
        
        case enweekdays::thur :
        return "thursday";
        break ;
        
        case enweekdays::weed :
        return "wednsday";
        break;
        
        case enweekdays::thus :
        return "thusday";
        break ;
        
        case enweekdays::fri :
        return "friday" ;
        break ;
        
        case enweekdays::sat :
        return "saturday" ;
        break;
        
        default :
          return "your day number is not in week day please try again";
    }
}

int main()
{
    showweekdaymenuf();
    
    cout << " today is : " << getweekday(readweekdays()) << endl;
    
    return 0;
}


