#include <iostream>
#include <cmath>
using namespace std;

int main()
{
     
      // understand absolute function = (abs)
      
      cout << "absoute value of -10 : " << abs(-10) << endl;
      cout << " absoulet value of 10 : " << abs(10) <<endl;
    
    
    
    
    
    
    
    
    
    return 0;
}