#include <iostream>
#include <string>

using namespace std ;

int main()
{
      
      // homework number 1
    
    string st1 = "43.22";
    
    double num_double = stod(st1);
    
    float num_float = stof(st1);
    
    int num_int = stoi(st1);
    
    cout << " num_int : " << num_int << endl;
    cout << " num_double : " <<num_double << endl;
    cout << " num_float : " << num_float<<endl;
    
    // homewok number 2 
    
    int n1 = 20 ;
    double n3 = 33.5 ;
    
    string st , st3;
    
    st = to_string(n1);
    st3 = to_string(n3);
    
    cout <<" string num : " << st << endl;
    cout << " string num : " << st3 << endl ;
     
    
     // homwork number 3     
    
    float n4 = 55.23;
    
    string st5 ;
    st5 = to_string(n4);
    
    int st6 = int(n4);
    int st7 = n4 ;
    int st8 = (int)n4;
    
    cout << " string f num : " << st5 << endl;
    cout << " int f : " << st6 << endl;
    cout << " int f : " << st7 << endl;
    cout << " int f : " << st8 << endl;
    
    
    
    
    
    return 0;
}