#include <iostream>
#include <cmath>
using namespace std;

 int main() 
 {
     
     float pi = 3.14 ;
     float r;
     
     
     cout << "please enter the number r : " << endl;
     cin >> r;
     
     cout << " circle area = " << ceil(pi*pow(r,2)) << endl;
     
     
     
     
     
     
     
     return 0;
 }

