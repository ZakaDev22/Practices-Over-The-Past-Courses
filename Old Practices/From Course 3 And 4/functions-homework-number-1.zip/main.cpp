#include <iostream>
#include <string>
using namespace std;

void functionh()
{
    cout << "  *    *  "<<endl;
    cout << "  *    *  "<<endl;
    cout << "  ******  "<<endl;
    cout << "  *    *  "<<endl;
    cout << "  *    *  "<<endl;
    
}

void iloveprograming()
{
    cout << " i love programing \n\n";
    cout << " i promise to be the bestdevloper ever\n\n";
    cout << " i know it will take same time to practice but i will acheve my goal\n\n";
    cout << " best regards.\n";
    cout << " mohammed abu_hadhoud\n";
    
}

void squarstars()
{
  cout <<"**********\n";
  cout <<"**********\n";
  cout <<"**********\n";
  cout <<"**********\n";
  cout <<"**********\n";
  cout <<"**********\n";
    
}

void displaymycardinfo()
{
cout << "*****************************************\n";
    cout << " name : mohammed abu_hadhoud " << endl;
    cout << " age : 44 " << endl;
    cout << " city : amman " << endl;
    cout << " country : jordan " << endl;
cout << "*****************************************\n";
    
}


int main()
{
    
    cout<<endl;
    
             displaymycardinfo();
    
cout<<endl;
    
             squarstars();
    
cout<<endl;
    
              iloveprograming();
    
cout<<endl;

             functionh();
    
    
    
    
    
    
    return 0;
}