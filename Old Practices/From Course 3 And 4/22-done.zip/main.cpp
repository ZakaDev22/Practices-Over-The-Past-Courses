
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    float pi = 3.14 ;
    float a;
    float b;
    
    cout << "please enter the number a : " << endl;
    cin >> a;
    
    cout << " please enter the number b : " << endl;
    cin >> b;
    
    cout << "circle area is : " << pi*(pow(b,2)/4) * ((2*a-b)/(2*a+b)) <<endl;
    
    cout << "the final results = " << floor(pi*(pow(b,2)/4) * ((2*a-b)/(2*a+b)))<<endl;
    

    
     return 0;
}