#include <iostream>
#include <string>
using namespace std;




  void myfunction(int num1 , int num2 ,int num5)
  {

      cout << " my function is : " << num1 * num2 - num5 << endl;
      
  }


 int myfunction2(int num3 , int num4)
 {
     
     return num3 * num4 ;
 }
 
int main()
{
       int num1 , num2 , num5;
       
        cout << "please enter the num 1 : " <<endl;
      cin >> num1 ;
      
      cout << "please enter the num 2 : " << endl;
      cin >> num2 ; 
      
      cout << " please enter num 5 : " << endl;
      cin >> num5;
       
        myfunction(num1,num2,num5) ;
        
    cout << "____________________________________________________\n";
    
         int num3 , num4 ;
         
         cout << "please enter num 3 : " << endl;
         cin >> num3 ;
         
         cout << " please enter num 4 :" << endl;
         cin >> num4 ;

         cout << " this is my function 2 : " << myfunction2(num3 , num4 )<<endl;
    
    
    
    
   
    return 0;
}


