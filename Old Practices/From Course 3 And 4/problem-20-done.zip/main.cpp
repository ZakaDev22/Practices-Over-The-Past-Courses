
#include <iostream>

using namespace std;

int main()
{
      float number1 ; 
       
       cout << " please enter the number : " << endl; 
       cin >> number1; 
        
         cout << endl; 
         
        cout << " circle area inscribed in a square = " << (3.14 * number1 * number1 )/4 <<endl;
     
      
       

    return 0;
}