
#include <iostream>
#include <cmath>

using namespace std;

 enum color { red , green=20, yellow , blue };
 enum direction { north , south=2002  , east , west};
 enum week { sat , sun , mon, tue ,wed , thu , fri = 11};
 enum gendor { male =1, famale};
 enum status  {single , married };
 
 
int main()
{
    color mycolor ;
    direction mydirection;
    week today;
    gendor morf;
    status mystatus;
    
    mycolor = color::green;
    mydirection = direction::south;
    today = week::fri;
    morf = gendor::male;
    mystatus=status::single;
    
    cout << "my fav color : " << mycolor << endl;
    cout << " my direction : " << mydirection<<endl;
    cout << " my fav day in the week : " << today<<endl;
    cout << " my gendor : " << morf << endl;
    cout << "my status : " << mystatus << endl;
    
    
    
    

    return 0;
}
