#include <iostream>
#include <cmath>

 using namespace std;
 
 int main()
 {
       // understand roundin (round)
     
     cout << "round value of 2.4 : " << round(2.4) << endl; 
     
     cout << "round value of 2.5 : " << round(2.5) << endl;
     
     cout << "round value of 2.6 : " << round(2.6) << endl;
     
     cout<<endl;
     
     cout << " souar root of 50 : " << sqrt(50) << endl;
     cout << " round value of sqrt(50) : " << round(sqrt(50)) << endl;
     cout<<endl;
     
     cout <<  round(2.4) + round(5.6) + round(2.3) << endl<<endl;
     
     cout << round(6.3) /2 <<endl<<endl;
     
     cout << round(9.1) + 1 <<endl;
     
     
     
     
      
      
      return 0;
 }
