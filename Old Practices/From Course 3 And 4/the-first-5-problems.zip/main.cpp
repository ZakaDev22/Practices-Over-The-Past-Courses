#include <iostream>

#include <string>

using namespace std ;
                                //  problem number 1 done

void printname( string name )
{
    cout << "\n \t your name is : " << name << endl;
}


int main()
{
    
    printname("zakaria ") ;
    
    
    return 0;
}