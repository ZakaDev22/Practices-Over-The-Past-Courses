
#include <iostream>

using namespace std;

int main()
{
     short firstnumber ; 
     short secondnumber ; 
      
      cout << " please enter the first number : " << endl; 
      cin >> firstnumber ; 
       
       cout << " please enter the second number : " << endl; 
       cin >> secondnumber ; 
        
        cout << " 9 + 2 = " << firstnumber + secondnumber << endl; 
        cout << " 9 - 2 = " << firstnumber - secondnumber << endl; 
        cout << " 9 * 2 = " << firstnumber * secondnumber << endl; 
        cout << " 9 / 2 = " << firstnumber / secondnumber << endl; 
        cout << " 9 % 2 = " << firstnumber % secondnumber << endl;
      
       
    return 0;
}