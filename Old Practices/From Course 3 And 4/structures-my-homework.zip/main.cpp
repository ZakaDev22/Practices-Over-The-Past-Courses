#include <iostream>
#include <cmath>
using namespace std;

 struct skzl
 {
     string love;
     string longtime;
     
     
 };
 
 
 struct siya
{
    int age;
    string name;
    string adresse;
};

struct zaka 
{
    string facbook;
    int watsapp;
    string instagram;
    siya siyaml;
    skzl lovestory;
};


 int main()
{
    
    zaka information1 ;
    
    information1.facbook = "zakaria elfakhar";
    information1.watsapp = 1111 ;
    information1.instagram = " zaka el ";
    
    information1.siyaml.age = 22 ;
    information1.siyaml.name = " my caty" ;
    information1.siyaml.adresse = " my heart ";
    
    zaka information2 ;
    
    information2.lovestory.love = " 1 year ago " ;
    information2.lovestory.longtime = " for ever " ;
    
    
    cout << "****************************************\n";
    cout << "my facbook : " <<information1.facbook<<endl;
    cout << " my watsapp : " << information1.watsapp<<endl;
    cout << " my instagram : " <<information1.instagram<<endl;
    cout << " my siya age : " << information1.siyaml.age<<endl;
    cout << " my siya name : " << information1.siyaml.name<<endl;
    cout << " my siya adresse : " << information1.siyaml.adresse <<endl;
    cout << "________________________________________\n";
    cout << " s.love.z time : " << information2.lovestory.love<<endl;
    cout << " s.love.z go to : " << information2.lovestory.longtime<<endl;
    cout << "*******************************************\n";
    
    
    
    return 0;
}