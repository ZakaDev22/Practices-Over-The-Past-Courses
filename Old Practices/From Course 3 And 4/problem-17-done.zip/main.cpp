
#include <iostream>

using namespace std;

int main()
{
      short number1 ; 
      short number2;  
      
       cout << " plese enter the first number : " << endl; 
       cin >> number1 ;
     
       cout << " please enter the second number : " << endl; 
       cin >> number2; 
        
        cout << endl; 
        
        cout << " the triangle area is = "  <<  number1 /2 * number2 << endl;

    return 0;
}