
#include <iostream>

using namespace std ;
                                  // # 6  done

struct stinfo
{
    string firstname ;
    string lastname ;
    string caty  ;
    
};

stinfo readinfo()
{
    stinfo info ;
    
    cout << " please enter your first name : " << endl;
    cin >> info.firstname ;
    
    cout << " please enter your last name : " << endl;
    cin >> info.lastname ;
    
    cout << " please enter your caty : " << endl;
    cin >> info.caty ;
    
    return info ;
    
}

string getfullname(stinfo info , bool reversed)
{
    string fullname ;
    
    
     if(reversed)
        fullname = info.firstname +" "+ info.lastname +"\n\n end your caty is "+ info.caty ;
        
     else
        fullname = info.lastname +" "+ info.firstname +"\n\n end your caty is "+ info.caty ; 
   
   return fullname ;
}

void printfull_name(string fullname)
{
    cout << " your full name is : " << fullname << endl;
}


int main()
{
    printfull_name( getfullname( readinfo(),false ) );
    
    
    return 0;
}