#include <iostream> 
using namespace std; 
 
 int main() 
 { 
     
      float seconds; 
      float minutes; 
      float hours;
      float days;
       
        cout << "please enter the days : " << endl; 
        cin >>days; 
        
        cout << " please enter the hours : " <<endl; 
        cin >>hours;
         
        cout << "please enter the minutes : " <<endl; 
        cin >>minutes; 
        
        cout << " please enter the seconds : "  <<endl; 
        cin >> seconds;
          
          cout << endl;
          
         cout << "total second is : " << days*24*60*60 + hours*60*60 + minutes*60 + seconds << endl;
            
            
             
             
              
              
       
        
         
          
           
            
            
             
              
              
              
              return 0;
 }