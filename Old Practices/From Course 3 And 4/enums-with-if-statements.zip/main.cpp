#include <iostream>

using namespace  std ;

enum encountry { maroc=1 , jordan=2 , algerai=3 , tunis=4};


int main()
{
    cout << "**************************************************\n";
      cout << " please chois the number of your country : " << endl;
      cout << " (1) maroc " << endl;
      cout << " (2) jordan " << endl;
      cout << " (3) algerai " << endl;
      cout << " (4) tunis " << endl;
      cout << " your chois is ?" << endl;
    cout <<"*****************************************************\n";
      
      int c ;
      encountry country ;
      
      cin >> c ;
      
      country = (encountry)c ;
      
      if (country == encountry::maroc)
      {
          cout << " your country is maroc " << endl;
      }
      
      else if (country == encountry::jordan)
      {
          cout << " your country is jordan " << endl;
      }
      
      else if ( country == encountry::algerai)
      {
          cout <<" your country is algerai " << endl;
      }
      
      else if ( country == encountry::tunis)
      {
          cout << " your country is tunis " << endl;
      }
      
      else 
      {
          cout << " your country is not in this system " << endl;
      }
  
    return 0;
}