#include <iostream>
#include <string>
#include <cmath>

using namespace std;


struct teacherinfo
{
    string name ;
    int age ;
    string city;
    string country;
    float monthlysalary;
    float yearlysalary;
    char gender ;
    bool married ;
    
};


void readinfo(teacherinfo &info)
{
    cout << " please enter the your name : " << endl;
    cin.ignore(1,'\n');
    getline(cin,info.name);
    
    cout << " please enter your age : " << endl;
    cin >> info.age ;
    
    cout << " please enter your city : " << endl;
    cin >> info.city ;
    
    cout << " please enter your country : " << endl;
    cin >> info.country ;
    
    cout << " please enter your monthly salary : " << endl;
    cin >> info.monthlysalary ;
    
    cout << " please enter your yearly salary : " << endl;
    cin >> info.yearlysalary ;
    
    cout << " please enter your gender : " << endl ;
    cin >>  info.gender ;
    
    cout << " please enter are you marriead  if yes enter 1 if no enter 0 : " <<endl;
    cin >> info.married ;
    
              cout << endl << endl;
    
}

void printinfo(teacherinfo info)
{
    
  cout << "****************************************************************************\n";
     cout << " name : " << info.name << endl;
     cout << " age : "  << info.age <<" years" << endl;
     cout << " city : " << info.city << endl;
     cout << " country : " << info.country << endl;
     cout << " monthly salary : " << info.monthlysalary << endl;
     cout << " yearly salary : " << info.yearlysalary << endl;
     cout << " gender : " << info.gender << endl;
     cout << " married : " << info.married << endl;
  cout << "*******************************************************************************\n";
    
    
}

int main()
{
    
    teacherinfo person1info ;   // this steo for my teacher home work iformation
    readinfo(person1info);
    printinfo(person1info);
    
    teacherinfo person2info ;   // this fo my information  
    readinfo(person2info);
    printinfo(person2info);
    
    
    
    
    return 0;
}