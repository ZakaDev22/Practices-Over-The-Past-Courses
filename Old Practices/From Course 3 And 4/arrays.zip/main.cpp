#include <iostream>
#include <string>
using namespace std ; 




 

int main()
{
     float  gradenumbers[3]  ; 
    
    //   gradenumbers[0] ;
    //  gradenumbers[1] ; 
    //   gradenumbers[2] ;
     
     cout << " please enter the first grade : " << endl ;
     cin >> gradenumbers[0] ;
     
     cout << " please enter the seconde grade : " << endl;
     cin >> gradenumbers[1] ;
     
     cout << " please enter the third grade : " << endl;
     cin >> gradenumbers[2] ;
     

     cout << " the average of grades : " << (gradenumbers[0] + gradenumbers[1] + gradenumbers[2])/3 << endl;
    
    
    return 0;
}