 #include <iostream>
  #include <cmath>
  
  using namespace std;
  
  int main()
  {
      float a ;
      float d ;
      

      cout << " please enter the number a : " << endl;
      cin >> a;
      
     
      cout << " plese enter the number d : " << endl;
      cin >> d;
      
      
      cout << " the rectangle area = " << a*sqrt(pow(d,2)-pow(a,2)) <<endl;
      
      
      
      
      
      
      return 0;
  }
      
      
      
      