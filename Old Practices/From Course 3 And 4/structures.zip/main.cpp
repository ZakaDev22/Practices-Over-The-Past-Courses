#include <iostream>
#include <cmath>
using namespace std;


struct stadresse
{
    string street ;
    unsigned short homenumber;
    string city;
    
    
};




struct stowner 
{
    
    string fullname ;
    string phone ;
    unsigned short age;
    stadresse adresse;
    
    
  };
  


struct car
{
    string brand;
    string model;
    int year;
    stowner owner;
    
  };
  
    
int main()
{
    car maycar1 , maycar2 , mayrealcar , mayfirstcar ;
    
    maycar1.brand ="bmw" ;
    maycar1.model ="x5";
    maycar1.year = 2000;
    
    maycar2.brand ="zaka";
    maycar2.model ="zz";
    maycar2.year = 2002;
    
    mayrealcar.brand = "serkoss";
    mayrealcar.model ="s";
    mayrealcar.year = 2000;
    
    mayfirstcar.owner.fullname = "zakaria elfakhar";
    mayfirstcar.owner.phone = "665365122355";
    mayfirstcar.owner.age =  20 ;
    
    mayfirstcar.owner.adresse.street = "alkasbah drb albaghala";
    mayfirstcar.owner.adresse.homenumber = 98 ;
    mayfirstcar.owner.adresse.city = "marakech";
    
    
    
    cout << maycar1.brand << "\t" << maycar1.model << "\t" << maycar1.year << endl;
    
    cout << maycar2.brand << "\t" <<maycar2.model << "\t" <<maycar2.year <<endl;
    
    cout << mayrealcar.brand<< "\t" << mayrealcar.model <<"\t" <<mayrealcar.year <<endl<<endl;
    
    
    
    cout << "my name : " << mayfirstcar.owner.fullname <<endl;
    cout <<"my phone number : " << mayfirstcar.owner.phone << endl; 
    cout << " i have " <<  mayfirstcar.owner.age << " years old " << endl<<endl;
    
    
    
    cout << " my adrees is : " << mayfirstcar.owner.adresse.street << endl;
    cout << "my home number is : " << mayfirstcar.owner.adresse.homenumber << endl;
    cout << " my city is : " << mayfirstcar.owner.adresse.city << endl;
    
    
    
    
    
    
     return 0;
}
