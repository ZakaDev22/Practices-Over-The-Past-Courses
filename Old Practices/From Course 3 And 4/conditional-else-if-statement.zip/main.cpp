#include <iostream>

#include <string>

using namespace std ;



int main()
{
    
    //  home work done 
 
   
 
    return 0;
}