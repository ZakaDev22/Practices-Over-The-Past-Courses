#include <iostream> 

  using namespace std ; 
    
    int main() 
    { 
         
         unsigned short firstnumber ; 
         unsigned short secondnumber ; 
          
          cout << " please enter the first number : " << endl; 
          cin >> firstnumber ; 
           
           cout << " please enter the second number : " << endl; 
           cin >> secondnumber ;   
            
            cout << endl<<endl;
            
        cout << " half of " << firstnumber << " is : " << firstnumber / 2 <<endl; 
        cout << " half of " << secondnumber << " is : " << secondnumber / 2 << endl; 
        
           
            
             
              return 0;        
                 
    }
   