#include <iostream>
#include <string>

using namespace std;



void myfunction()
{
    cout << " this is my firt function :) " << endl;
    
}

void myfunction2()
{
    
    cout << " this is my second function :) " << endl;
}

int main()
{
    
    myfunction();
    
    myfunction2();
    
    
    
    
    
    return 0;
}