
#include <iostream>

using namespace std;

int readthenumber(string message)
{
    int number;
    
    cout << message << endl;
    cin >> number ;
    
    return number;
}

void print_inerted_pattern(int number)
{
  for(int i=1 ; i <= number ; i++)
  {
       for(int z = 1 ; z <=i ; z++)
       {
          cout << i ;
      }
      cout << endl;
  }
  
}

int main()
{

    print_inerted_pattern(readthenumber("please enter a positiv number "));
 
    return 0;
}