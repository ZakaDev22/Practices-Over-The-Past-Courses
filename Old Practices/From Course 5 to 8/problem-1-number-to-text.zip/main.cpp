#include <iostream>

#include <string>
#include <vector>
#include <cctype>

using namespace std;

string ConvertNumberToText(int Number)
{
	if (Number == 0)
		return "";

	if (Number >= 1 && Number <= 19)
	{
		string arr[] = { "","One","Two","three" ,"four" ,"five" ,"six" ,"Seven" ,"Eight" ,"Nine" ,"Ten" ,"Eleven"
						 ,"Twelve" ,"thirteen" ,"fourtenn" ,"fifteen" ,"sixteen" ,"Seventeen" ,"Eighteen" ,"Nineteen" };

		return arr[Number] + " ";
	}

	if (Number >= 20 && Number <= 99)
	{
		string arr[] = { "","","Twenty","thirty","fourty" ,"fifty" ,"sixty" ,"Seventy" ,"Eighty" ,"Ninety"};

		return arr[Number / 10] + " " + ConvertNumberToText(Number % 10);
	}

	if (Number >= 100 && Number <= 199)
	{
		return " One Hundred " + ConvertNumberToText(Number % 100);
	}

	if (Number >= 200 && Number <= 999)
	{
		return ConvertNumberToText(Number / 100) + " Hundreds " + ConvertNumberToText(Number % 100);
	}

	if (Number >= 1000 && Number <= 1999)
	{
		return " One Thousend " + ConvertNumberToText(Number % 1000);
	}

	if (Number >= 2000 && Number <= 999999)
	{
		return  ConvertNumberToText(Number / 1000) + " Thousends " + ConvertNumberToText(Number % 1000);
	}

	if (Number >= 1000000 && Number <= 1999999)
	{
		return " One Million " + ConvertNumberToText(Number % 1000000);
	}

	if (Number >= 2000000 && Number <= 999999999)
	{
		return ConvertNumberToText(Number / 1000000) + " Millions " + ConvertNumberToText(Number % 1000000);
	}

	if (Number >= 1000000000 && Number <= 1999999999)
	{
		return " One Billion " + ConvertNumberToText(Number % 1000000000);
	}

	else
	{
		return ConvertNumberToText(Number / 1000000000) + " Billions " + ConvertNumberToText(Number % 1000000000);
	}
}

int readNumber()
{
	int number = 0;

	cout << "\n please Enter a Number? ";
	cin >> number;

	return number;
}

int main()
{
	unsigned int Number = readNumber();

	cout << "\n Your Number After Convertig To Text :   " << ConvertNumberToText(Number) << endl;

	system("pause>0");
	return 0;
}