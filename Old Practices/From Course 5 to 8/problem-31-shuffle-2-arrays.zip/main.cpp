#include <iostream>

#include <cstdlib>

using namespace std ;

int readrandomnumber(int from , int to)
{
    int number = rand() % (to - from + 1) + from ;
    
    return number ;
}

void SwaoNumbers(int& A , int& B)
{
    int temp = A ;
    A = B ;
    B = temp ;
}

void read_arrays(int arr[100] , int& arrlength)
{
    cout << "\n enter how meny elimenet do you want : " << endl;
    cin >> arrlength ;
    
    int num =0;
    
     for(int i=0 ; i<arrlength ; i++)
     {
         num++ ;
         
         arr[i] = num ;
     }
     
     cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
   
    for(int i=0 ; i<arrlength ; i++)
     {
         cout << arr[i] << " " ;
     }
     
     cout << endl;
}

void ShuffleArrayIlements(int arr[100], int arrlength)
{
    for(int i=0 ; i<arrlength ; i++)
    {
      SwaoNumbers(arr[readrandomnumber(1,arrlength)-1] , arr[readrandomnumber(1,arrlength)-1]);
    }
    cout << endl;
}


int main()
{
    srand((unsigned)time(NULL));
    
    int arr[100] ,  arrlength ;
    
    read_arrays(arr , arrlength);
    
    cout << "\n array ilements befor shuffle : ";
    print_arrays(arr , arrlength);
    
    ShuffleArrayIlements(arr , arrlength);
    
    cout << "\n array ilements after shuffle : ";
    print_arrays(arr,arrlength);
    
    
    return 0;
}


