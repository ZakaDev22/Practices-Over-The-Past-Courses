
#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;

vector <string> SplitString(string s1, string delim)
{
	vector <string> vWords;

	short pos = 0;

	string sWord;

	while ((pos = s1.find(delim)) != std::string::npos)
	{
		sWord = s1.substr(0, pos);

		if (sWord != "")
		{
			vWords.push_back(sWord);

		}
		s1.erase(0, pos + delim.length());
	}

	if (sWord != "")
	{
		vWords.push_back(s1);
	}

	return vWords;
}

string ReplaceStringWords(string s1, string delim, string stringtoReplece, string replaceTo, bool matchcase = true)
{
	vector <string> vwords;
	vwords = SplitString(s1 ," ");

	for (string& s : vwords)
	{
		if (matchcase)
		{
			if (s == stringtoReplece)
			{
				s = replaceTo;
			}
		}
		else
		{
			if (mylib::TolowerallTheString(s) == mylib::TolowerallTheString(stringtoReplece))
			{
				s = replaceTo;
			}
		}
	}

	return mylib::JoinString(vwords, " ");
}

int main()
{
    // welcom to Jordan , Jordan is nice country

	string stringtoReplece = "jordan";

	string replaceTo = "USA";

	string s1 = "welcom to Jordan , Jordan is nice country";

	cout << "\n string befor Replace : " << s1 << endl;

	cout << "\n string After Replace wiht match case   : ";
	cout << ReplaceStringWords(s1, " " , stringtoReplece, replaceTo) << endl;

	cout << "\n string After Replace whit nomatch case : ";
	cout << ReplaceStringWords(s1, " ", stringtoReplece, replaceTo,false) << endl;




	return 0;
}