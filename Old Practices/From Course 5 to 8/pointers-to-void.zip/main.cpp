#include <iostream>

using namespace std;

int main()
{
	void * ptr;

	float z = 21.1;

	ptr = &z;

	cout << ptr << endl;

	cout << *(static_cast<float*>(ptr)) << endl; // use this code to convert a float variabel to any other variabels..

	int s = 23;
    
	ptr = &s;

	cout << ptr << endl;
	cout << *(static_cast<int*>(ptr)) << endl;


	

	return 0;
}