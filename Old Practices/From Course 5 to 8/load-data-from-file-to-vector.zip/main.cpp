#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

void getDataFromFileToVector(string filename , vector <string> & vFileContent )
{
	fstream MyFile;

	MyFile.open(filename, ios::in); // read mode;

	string copyline;

	while (getline(MyFile, copyline))
	{
		vFileContent.push_back(copyline);
	}

	MyFile.close();
}

int main()
{
	vector <string> vFileContent;

	getDataFromFileToVector("MyFile.text" , vFileContent);

	for (string& line : vFileContent)
	{
		cout << line << endl;
	}
	

	return 0;
}