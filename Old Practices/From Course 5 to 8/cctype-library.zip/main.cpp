#include <iostream>

#include <cctype>

using namespace std;


int main()
{
	char z;
	char w;

	z = toupper('a');
	w = tolower('A');

	cout << " convirting a to A : " << z << endl;
	cout << " convirting A to a : " << w << endl;

	cout << " isupper('A') : " << isupper('A') << endl;
	cout << " islower('a') : " << islower('a') << endl;

	cout << " isdigit('2') : " << isdigit('2') << endl;

	cout << " ispunct(';') : " << ispunct(';') << endl;




	return 0;
}

