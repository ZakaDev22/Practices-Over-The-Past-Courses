#include<iostream>
 #include<iomanip>  // this library stored the std::setwusingnamespace std; 

using namespace std;

int main()
{

	cout << "-----------|---------------------------|------------| " << endl;   // 11 - , 27 - , 12 -
	cout << "  Code     |          Name             |    Mark    | " << endl;
	cout << "-----------|---------------------------|------------| " << endl;

	cout << setw(11) << "z102" << "|" << setw(27) << "zakaria the wolf " << "|" << setw(12) << "21" << "|" << endl;

	cout << "-----------|---------------------------|------------| " << endl;

	cout << setw(11) << "s51" << "|" << setw(27) << "ssiya My Caty " << "|" << setw(12) << "23" << "|" << endl;

	cout << "-----------|---------------------------|------------| " << endl;

	cout << setw(11) << "zs<3" << "|" << setw(27) << " for ever " << "|" << setw(12) << "<333" << "|" << endl;

	cout << "-----------|---------------------------|------------| " << endl;



	return 0;
}