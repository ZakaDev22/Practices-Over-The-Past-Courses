#include <iostream>
#include <cstdlib>

using namespace std;

short ReadRandomNumbers(short from, short to)
{
	short num = rand() % (to - from + 1) + from;

	return num;
}

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{
	

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr[i][j] = ReadRandomNumbers(1, 10);
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			printf(" %0*d ", 2, arr[i][j]);
		}
		cout << endl;
	}
}

void Multiplay2Matrix(int arr[3][3], int arr1[3][3], int arr2[3][3], short rows, short cols)
{
	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr2[i][j] = arr[i][j] * arr1[i][j];
		}

	}
}

int main()
{
	srand((unsigned)time(NULL));

	int arr[3][3];
	int arr1[3][3];
	int arr2[3][3];

	FillMatrixRandom3x3Numbers(arr, 3, 3);
	FillMatrixRandom3x3Numbers(arr1, 3, 3);


	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(arr, 3, 3);

	cout << "\n\n Matrix 2 : \n\n";
	PrintMatrixRandom3x3Numbers(arr1, 3, 3);

	//ar * ar1 in ar3
	Multiplay2Matrix(arr, arr1, arr2, 3, 3);

	cout << "\n\n Matrix 3 result of arr1 * arr2 : \n\n";
	PrintMatrixRandom3x3Numbers(arr2, 3, 3);
	

	return 0;
}
