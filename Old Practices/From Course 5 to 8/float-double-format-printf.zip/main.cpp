#include <iostream>

using namespace std;


int main() {

	float pi = 3.14159265359;

	printf("presecision specification %.*f  \n\n", 1, pi );
	printf("presecision specification %.*f  \n\n", 2, pi);
	printf("presecision specification %.*f \n\n",  3, pi);
	printf("presecision specification %.*f \n\n",  4, pi);

	float z = 21.1, s = 23.3;

	printf(" the float divicion : %.3f / %.3f = %.3f \n\n", z , s , z/s);
   
	double age = 21.23; 

	printf(" the double value = %.2f \n\n", age);
	printf(" the double value = %.3f \n\n", age);



	return 0;
}