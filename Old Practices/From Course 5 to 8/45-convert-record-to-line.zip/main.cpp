#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;

struct stClientData
{
	string accountnumber = "";
	string pincode = "";
	string fullname = "";
	string phone = "";
	double accountbalance = 0;
};

stClientData Readclientdata()
{
	stClientData clientdata;

	cout << "\n enter your full name \n";
	getline(cin, clientdata.fullname);

	cout << "\n enter your account number \n";
	getline(cin, clientdata.accountnumber);

	cout << "\n enter your pin code \n";
	getline(cin, clientdata.pincode);

	cout << "\n enter your phone number \n";
	getline(cin, clientdata.phone);

	cout << "\n enter your account balance \n";
	cin >> clientdata.accountbalance;

	return clientdata;
}


string printallinfoinOneLine(stClientData clientdata , string seperator= "#//#")
{
	string stclientrecord = "";

	stclientrecord += clientdata.fullname + seperator;
	stclientrecord += clientdata.accountnumber + seperator;
	stclientrecord += clientdata.phone + seperator;
	stclientrecord += clientdata.pincode + seperator;
	stclientrecord += to_string(clientdata.accountbalance);

	return stclientrecord;
}

int main()
{

	stClientData clientdata;

	clientdata = Readclientdata();

	cout << "\n client Record for saving is :\n\n";

	cout << printallinfoinOneLine(clientdata) << "\n\n";
	



	return 0;
}