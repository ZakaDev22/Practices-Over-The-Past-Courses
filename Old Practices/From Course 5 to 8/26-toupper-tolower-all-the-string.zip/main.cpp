#include <iostream>
#include <string>
#include <cctype>

using namespace std;


string readstring()
{
	string s1 = "";

	cout << "\n please enter the string you want! : ";
	getline(cin, s1);

	return s1;
}

string TolowerallTheString(string s1)
{

	

	for (int i = 0; i < s1.length(); i++)
	{
			s1[i] = tolower(s1[i]);
	}
	return s1;
}

string ToUpperAllTheString(string s1)
{


	for (int i = 0; i < s1.length(); i++)
	{
			s1[i] = toupper(s1[i]);
	}
	return s1;
}

int main() {

	//s1 = Zakaria Wolf Elfakhar @ Programming Advices.

	string s1 = readstring();


	s1 = ToUpperAllTheString(s1);

	cout << " \n s1 string after upper all letters : ";
	cout << s1 << endl;

	s1 = TolowerallTheString(s1);

	cout << " \n s1 string after lower all letters : ";
	cout << s1 << endl;
   
	return 0;
}