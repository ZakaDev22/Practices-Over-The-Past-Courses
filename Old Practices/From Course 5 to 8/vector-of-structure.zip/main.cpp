#include <iostream>
#include <vector>

using namespace std;

struct steEmployes {

	string firstname = "";
	string lastname = "";
	float salary = 0;
};


int main()
{
	
	vector <steEmployes> vemmployes;

	steEmployes tempemployes;

	tempemployes.firstname = "zakaria"; 
	tempemployes.lastname = "elfakhar";
	tempemployes.salary = 10000;
	vemmployes.push_back(tempemployes);

	tempemployes.firstname = "mohammed";
	tempemployes.lastname = "abou_hadhoud";
	tempemployes.salary = 5000;
	vemmployes.push_back(tempemployes);

	tempemployes.firstname = "ziko";
	tempemployes.lastname = "wolf";
	tempemployes.salary = 99999;
	vemmployes.push_back(tempemployes);

	cout << " employes vector : \n\n";

	for(steEmployes &employes : vemmployes)
	{
		cout << "first name : " << employes.firstname << endl;
		cout << "first name : " << employes.lastname << endl; 
		cout << "first name : " << employes.salary << endl;
		cout << endl;
	}

	

	return 0;
}