#include <iostream>
#include <cstdlib>
                                            // My Solution
using namespace std;

int  readrandnumber(int from, int to)
{
	//  functionto generate random number

	int reandnum = rand() % (to - from + 1) + from;

	return  reandnum;
}

void FillMatrixRandom3x3Numbers()
{
	int ArrMat[3][3];



	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			ArrMat[i][j] = readrandnumber(1, 100);
		}
		cout << endl;
	}
}

void PrintMatrixRandom3x3Numbers()
{
	int ArrMat[3][3];



	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			printf("%0*d", 2, ArrMat[i][j]) ;
			
			cout << "\t";
		}
		cout << endl;
	}
}

int main()
{
	srand((unsigned)time(NULL));
     
    cout << "\n the following is 3x3 random matrix ";
     	
	FillMatrixRandom3x3Numbers();

	PrintMatrixRandom3x3Numbers();

	return 0;
}