#include <iostream>
#include <string>
#include <cctype>

#include "MyStringLib.h" 

using namespace std;

char readchar()
{
	char char1;
	cout << "\n Enter a charater ? \n";
	cin >> char1;

	return char1;
}

bool IsVowel(char char1)
{
	char1 = tolower(char1);
	
	return (('a' == char1) || ('i' == char1) || ('o' == char1) || ('e' == char1) || ('u' == char1));
}


int main() {

	//  Programming ADvices.
	
	char char1 = readchar();
	
	if (IsVowel(char1))
		cout << "\n Yes : the character " << char1 << " is Vowel \n";
	
	else
		cout << "\n no : the character " << char1 << " is not Vowel \n";

	return 0;
}