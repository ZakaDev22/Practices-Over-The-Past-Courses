#include <iostream>

using namespace std ;

string readthepasword()
{
    string text ;
    
    cout << " please enter your paswword  : " << endl;
    getline(cin , text);
    
    return text ;
}

 short readthepasword_key(string message)
{
    short passwordkey =0;
    
    cout << message << endl;
    cin >> passwordkey ;
    
    return passwordkey ;
} 

string encryption(string text , short passwordkey)
{

    for(int i=0 ; i<= text.length() ;i++)
    {
        text[i] = char((int)text[i] + passwordkey)  ;
    }
    
    return text;
}

string decryption(string text , short passwordkey)
{
    
    for(int i=0; i<= text.length() ;i++)
    {
        text[i] = char((int)text[i] - passwordkey)  ;
    }
    
    return text;
    
}

int main()
{
    
    string text = readthepasword();
    
    short passwordkey =  readthepasword_key("please enter your password key!");
    
     string encryptionthetext= encryption(text , passwordkey);
     
     string decryptionthetext = decryption(encryptionthetext , passwordkey);
     
     cout << "\n\t text befor encryption : " << text << endl;
     cout << " \n\t text after encryption : " << encryptionthetext << endl;
     cout << "\n\t text after decryption : " << decryptionthetext << endl;
     
    return 0;
}




