#include <iostream>
#include <iomanip>

using namespace std;

void PrintFibonacciSeries(int array[10], int& lenght)
{

    for (int i = 0; i < lenght; i++)
    {
        array[i] = 1;

        if (i == 1)
        {
            array[i] = array[i - 1];
        }

        if (i >= 2)
        {
            array[i] = array[i - 1] + array[i - 2];
        }

        cout << setw(3) << array[i] << " ";
    }
    cout << "\n\n";
}

int main()
{
    int array[10], lenght = 10;

    cout << " \n\n fibonacci series of array[10] is  :  ";

    PrintFibonacciSeries(array, lenght);

    return 0;
}



