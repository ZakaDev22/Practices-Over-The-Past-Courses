#include <iostream>

#include <cstdlib>
                                                                    // # my solution
using namespace std ;

int readrandomnumber(int from , int to)
{
    int number = rand() %  (to - from + 1) + from ;
    
    return number ;
}

void read_arrays(int arr[100] , int& arrlength)
{
    cout << "\n enter how meny elimenet do you want : " << endl;
    cin >> arrlength ;
    
     for(int i=0 ; i<arrlength ; i++)
     {
         arr[i] = readrandomnumber(1,100) ;
     }
     cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
   
    for(int i=0 ; i<arrlength ; i++)
     {
         cout << arr[i] << " " ;
     }
     
     cout << endl;
}

void SumOf2ArraysInThirdArrayt(int arr[100] ,int arrlength , int arr2[100] , int arrlength2 , int arr3[100])
{
    
    for(int i=0 ; i<arrlength;i++)
    {
        arr3[i] = arr[i] + arr2[i] ;
    }
    cout << endl;
}

int main()
{
    
    srand((unsigned)time(NULL)) ;
    
    int arr[100] , arrlength ;
    
    read_arrays(arr , arrlength) ;
    
    int arr2[100] , arrlength2 ;
    read_arrays(arr2 , arrlength2);
    
    int arr3[100]  ;
    SumOf2ArraysInThirdArrayt(arr ,arrlength , arr2 , arrlength2 , arr3 ) ;
    
    cout << "\n  array 1 ilements : " ;
    print_arrays(arr , arrlength) ;
    
    cout << "\n  array 2 ilements : " ;
    print_arrays(arr2 , arrlength2) ;
    
    cout << "\n  sum of 2 arrays in third array : " ;
    print_arrays(arr3 , arrlength ) ;
    
    
    
   
    return 0;
}




