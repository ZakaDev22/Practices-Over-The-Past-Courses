#include <iostream>

//#include  "mypointerslib.h";

using namespace std;

struct stMyinfo
{
	short myage = 21;
	short mysalary = 10000;
	string myfullname = "zakaria the wolf";
	
};

struct stmycatyinfo
{
	short catyage = 23;
	short catysalary = 2300;
	string catyfullname = "my caty";

};

struct stfullinfo
{
	stMyinfo myinformation;

	stmycatyinfo catyinformation;
};

int main()
{
	stfullinfo  fullinformaton , * ptr;

	ptr = &fullinformaton;

	cout << "\n zakaria info using pointer :  " << endl;
	cout << "\n my age       : " << fullinformaton.myinformation.myage << endl;
	cout << "\n my salary    : " << fullinformaton.myinformation.mysalary << endl;
	cout << "\n my full name : " << fullinformaton.myinformation.myfullname << endl;

	cout << "\n ssiya info :  " << endl;
	cout << "\n my age       : " << fullinformaton.catyinformation.catyage << endl;
	cout << "\n my salary    : " << fullinformaton.catyinformation.catysalary << endl;
	cout << "\n my full name : " << fullinformaton.catyinformation.catyfullname << endl;

	cout << "----------------------- using pointers ---------------------------------------------\n\n";

	cout << "\n zakaria info using pointer :  " << endl;
	cout << "\n my age       : " << ptr-> myinformation.myage << endl;
	cout << "\n my salary    : " << ptr-> myinformation.mysalary << endl;
	cout << "\n my full name : " << ptr-> myinformation.myfullname << endl;

	cout << "\n ssuya info using pointer :  " << endl;
	cout << "\n my age       : " << ptr->catyinformation.catyage << endl;
	cout << "\n my salary    : " << ptr->catyinformation.catysalary << endl;
	cout << "\n my full name : " << ptr->catyinformation.catyfullname << endl;



	return 0;
}
