#include <iostream>

#include <string>
#include <vector>
#include <cctype>

using namespace std;

short ReadYear()
{
	short n = 0;

	cout << "\n Please Enter How Many Days In The Year You Want To Tcheck.? ";
	cin >> n;

	return n;
}

bool Is_LeapYear(short Year)
{

	return ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0));
		
}

int main()
{
	short Year = ReadYear();

	if (Is_LeapYear(Year))
	{
		cout << "\n Yes, Year [" << Year <<"] its A Leap Year." << endl;
	}
	else
		cout << "\n No, Year [" << Year << "] is Not Leap Year." << endl;


	system("pause>0");
	return 0;
}