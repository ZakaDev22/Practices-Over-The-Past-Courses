#include <iostream>
#include <string>
#include <cctype>

using namespace std;

string readString()
{
	string s;

	cout << "\n please enter the string you want to invert! \n";
	getline(cin, s);

	return s;
}

char invertCharacters(char letter)
{
	return isupper(letter) ? tolower(letter) : toupper(letter);
}

string InvertAllStringLettercase(string s1)
{
	for (short i = 0; i < s1.length(); i++)
	{
		s1[i] = invertCharacters(s1[i]);
	}

	return s1;
}

int main() {

	string s1 = readString();
	

	cout << "\n string After Inverting : \n";

	s1 = InvertAllStringLettercase(s1);

	cout << s1 << endl;
	
	return 0;
}
