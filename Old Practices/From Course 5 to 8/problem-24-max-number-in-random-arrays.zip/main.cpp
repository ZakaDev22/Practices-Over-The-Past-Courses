#include <iostream>

#include <cstdlib>

using namespace std ;

int readrandom(int from , int to)
{
    
     int randomnumber = rand() % (to = from + 1) + from ;
    
    return randomnumber ;
}

void readarray(int arr[100] , int& arrlength)
{
    cout << " \n enter how meny random numbers do you want : " << endl;
    cin >> arrlength ;
    
    for(int i=0 ; i < arrlength ; i++)
    {
        arr[i] = readrandom(50 , 100) ;
    }
}

void print_random_arrays(int arr[100] , int arrlength)
{
    int temp = 0 ;
    
    for(int i=0 ; i < arrlength  ; i++)
    {
        cout << arr[i] << " " ;
        
    }
    cout << endl;
  
}

int themaxnumber(int arr[100] , int arrlength)
{
    int max = 0 ;
    
    for(int i=0 ; i<arrlength ; i++)
    {
        if(arr[i] > max)
        {
            max = arr[i] ;
        }
    }
      return max ;
}

int main()
{
    srand((unsigned)time(NULL));
    
    int arr[100] , arrlength ;
    
    readarray(arr , arrlength);
    
    cout << "array ilements : " ;
    print_random_arrays(arr , arrlength);
    
    cout << "\n\t the max number = " << themaxnumber(arr , arrlength) ;
    

    
    return 0;
}
