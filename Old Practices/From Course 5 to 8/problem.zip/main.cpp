#include <iostream>

#include <cmath>

using namespace std;

void print_multiplicationtable()
{
    cout << "\n\n\n \t\t\t  [multiplication table] \n\n\n";
    cout << "\t";
    
   
    
    for(int i=1 ; i<=10 ; i++)
    {
        cout  << i << "\t" ;
    }
    
     cout << "\n_________________________________________________________________________________________\n" ;
}

string colostrem(int i)
{
    if(i<10)
    return "   |";
    
    else
      return "  |";
}

void print_results()
{
    print_multiplicationtable();
    
    for(int i=1 ; i<=10 ; i++)
    {
        cout  << " " << i << colostrem(i) << "\t";
        
        for(int z=1 ; z<=10 ; z++)
        {
            cout << z*i  << "\t";
        }
        cout << endl;
    }
}

int main()
{
  print_results();
  
  
    return 0;
}