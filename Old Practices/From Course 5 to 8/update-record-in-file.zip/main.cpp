#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

void loadDataFromFileToVector(string filename, vector <string>& vFileContent)
{
	fstream MyFile;
	MyFile.open(filename, ios::in); // read mode

	if (MyFile.is_open())
	{
		string line;
		while (getline(MyFile, line))
		{
			if (line != "")
			{
				vFileContent.push_back(line);
			}

		}
	}
	MyFile.close();
}

void SaveDataFromVectorToFile(string filename, vector <string> vFileContent)
{
	fstream MyFile;
	MyFile.open(filename, ios::out); // write mode

	if (MyFile.is_open())
	{
		for (string& line : vFileContent)
		{
			if (line != "")
			{
				MyFile << line << endl;
			}
		}
	}
	MyFile.close();
}

void DeleteCatyFromFile(string filename, string record , string newrecord)
{
	vector <string> vFileContent;

	loadDataFromFileToVector(filename, vFileContent);

	for (string& line : vFileContent)
	{
		if (line == record)
		{
			line = newrecord;
		}
	}
	SaveDataFromVectorToFile(filename, vFileContent);
}

void printDataFromFile(string filename)
{
	fstream MyFile;
	MyFile.open(filename, ios::in); // read mode

	if (MyFile.is_open())
	{
		string line;

		while (getline(MyFile, line))
		{
			cout << line << endl;
		}
	}
}

int main()
{

	cout << "\n\n file befor deleting caty : " << endl;
	printDataFromFile("MyFile.text");

	DeleteCatyFromFile("MyFile.text", "caty" , "ssiya");

	cout << "\n\n file after deleting caty : " << endl;
	printDataFromFile("MyFile.text");
	

	return 0;
} 