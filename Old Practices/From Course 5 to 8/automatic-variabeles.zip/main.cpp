#include <iostream>

using namespace std;

void MyAutoFunction() {

	auto myage = 21;
	auto mymony = 99999999999999999999999999.9999;
	auto myname = " zakaria  ";

	cout << " my age is " << myage << endl;
	cout << " mony that i will make is " << mymony << endl;
	cout << " my name is : " << myname <<endl;

}

int main() {

	MyAutoFunction();

	return 0;
}