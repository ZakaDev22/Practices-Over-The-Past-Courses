#include <iostream>
#include <cmath>

using namespace std ;

float readnumber()
{
    float number =0 ;
    
    cout << " please enter a number : " << endl;
    cin >> number ;
    
    return number ;
}

int my_sqrt_function(int number)
{
    return pow(number , 0.5)  ;
}

int main()
{
    float number = readnumber();
    
    cout << "\n\t my sqrt function : " << my_sqrt_function(number) << endl; 
    
    cout << "\n\t c++ sqrt function : " << sqrt(number) << endl; 
  
  
  
    return 0;
}





