#include <iostream>

using namespace std;

int readposiitvnumber(string message)
{
    int number ;
    
    cout << message << endl;
    cin >> number ;
    
    return number ;
}

void print_inverted_pattern_n(int number)
{
  for(int i = (number + 65 - 1) ; i >=65 ; i--)
  {
      for(int z=65 ; z <= i ; z++)
      {
          cout << char(i);
      }
      cout << endl;
  }
}

int main()
{
    print_inverted_pattern_n(readposiitvnumber("please enter a posiitv number"));
    
    
    return 0;
}