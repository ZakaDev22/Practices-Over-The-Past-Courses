#include <iostream>
#include <string>

using namespace std;

int main()
{
	string s1 = " my name is zakaria , i love prgramming " ;
	
	// delet characters from the string.
	s1.erase(0,10);
	
	// replace Words.
	s1.replace(pos, stringtoReplece.length(), replaceTo);

	// print the length of the string
	cout << s1.length() << endl;
	cout << endl;

	// print character AT string position 3
	cout << s1.at(4) << endl;
	cout << endl;

	// add @programming advices to the the end of string
	cout << s1.append(" @programming.advices ") << endl;
	cout << endl;

	// string length after update 
	cout << s1.length() << endl;
	cout << endl;

	// insert wolf in position 12 in string s1
	cout << s1.insert(12, " wolf ") << endl;
	cout << endl;

	// print from position 12 to pos 14
	cout << s1.substr(12, 14) << endl;
	cout << endl;

	// print letter A in the end of the string
	s1.push_back('A');
	cout << s1 << endl;
	cout << endl;

	// delete the last letter in the s1 string
	s1.pop_back();
	cout << s1 << endl;
	cout << endl;
	
	// find the wolf in the string
	cout << s1.find("wolf") << endl;
	cout << endl;

	
	cout << s1.find("WOLF") << endl;
	// if you not sure use this code
	if (s1.find("Wolf") == s1.npos)
	{
		cout << " the name you want not found in the string " << endl;
	}

	// clear all the string letters
	s1.clear();
	cout << s1 << endl;


	return 0;
}


