#include <iostream>
#include <cmath>

using namespace std ;

int readnumber(string message)
{
    int number=0;
    
    cout << message << endl;
    cin >> number ;
    
    return number ;
}

float my_abs_result(int number)
{
    if(number > 0)
     return number ;
     
    else
      return number * -1 ;
 
}

int main()
{
  int number =  readnumber(" enter a number ");
    
   cout << "\n\t my abs result :" << my_abs_result(number);
   
   cout << endl;
   
   cout << "\n\t c++ abs result : " << abs(number) ;
   
   
   
    
    return 0;
}






