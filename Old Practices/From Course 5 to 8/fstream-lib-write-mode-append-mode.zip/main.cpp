#include <iostream>

#include <fstream>

using namespace std;


int main()
{
	fstream MyFile;

	MyFile.open("MyFile.text", ios::out); //writ mode ;

	if (MyFile.is_open())
	{
		MyFile << " hi this is my firt file end im happy :) \n";

		MyFile << " im a wolf end i will make it :) \n";

		MyFile << " you will do it my new me :] \n";

		MyFile << " this is the begining .. \n";
	}




	return 0;
}


