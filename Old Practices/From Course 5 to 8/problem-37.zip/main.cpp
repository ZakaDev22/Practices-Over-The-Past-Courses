#include <iostream>
#include <cstdlib>

using namespace std;



int readrandomnumber(int from , int to)
{
    int num = rand() % (to - from + 1 )+from ;
    
    return num;
}

void read_arrays(int arr[100] , int& arrlength)
{
    cout << " enter how many ilements do you want in array : " << endl;
    cin >> arrlength;
    
    for(int i=0 ; i<arrlength ; i++)
    {
        arr[i] = readrandomnumber(1,100);
    }
    cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
   
    
    for(int i=0 ; i<arrlength ; i++)
    {
       cout << arr[i] << " ";
    }
    cout << endl;
}


void addarrayilementsin_second_array(int number ,int arr[100] ,int& arrlength2 )
{
   
    arrlength2++ ;
   
   arr[arrlength2-1] = number ;
}

void copyarryailements(int arrsours[100] ,int arrdistination[100],int arrlength,int arrlength2)
{
    for(int i=0;i<arrlength;i++)
     addarrayilementsin_second_array(arrsours[i],arrdistination,arrlength2);
}

int main()
{
  int arr[100] , arrlength =0 , arrlength2=0;
  
  read_arrays(arr,arrlength);
  
  int arr2[100] ;
  copyarryailements(arr,arr2,arrlength,arrlength2);
  
  cout << " \n\t array 1 ilements : ";
  print_arrays(arr,arrlength);
  
   cout << " \n\t array 2 ilements : ";
   print_arrays(arr,arrlength);
  
   
    
    return 0;
}




