#include <iostream>
#include <string>
#include <cctype>

using namespace std;

string readString()
{
	string s;

	cout << "\n please enter the string you want ! \n";
	getline(cin, s);

	return s;
}

char readchar()
{
	char char1;
	cout << "\n Enter a charater ? \n";
	cin >> char1;

	return char1;
}

short PrintCountCharacter(string s1 , char char1)
{
	short count = 0;

	for (int i = 0; i < s1.length(); i++)
	{
		if (s1[i] == char1)
			count++;
	}

	return count;
}

int main() {

	// Mohammed Abu-Hadhoud

	string s1 = readString();
	char char1 = readchar();
	
	cout << "\n letter [" << char1 << "] count = " << PrintCountCharacter(s1, char1) << endl;
	
	return 0;
}