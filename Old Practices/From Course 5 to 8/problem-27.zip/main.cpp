#include <iostream>

#include <cstdlib>

using namespace std ;

int readrandomnumber(int from , int to)
{
    int number = rand() %  (to - from + 1) + from ;
    
    return number ;
}

void read_arrays(int arr[100] , int& arrlength)
{
    cout << "\n enter how meny elimenet do you want : " << endl;
    cin >> arrlength ;
    
     for(int i=0 ; i<arrlength ; i++)
     {
         arr[i] = readrandomnumber(1,100) ;
     }
     cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
   
    for(int i=0 ; i<arrlength ; i++)
     {
         cout << arr[i] << " " ;
     }
     
     cout << endl;
}

int sum_of_random_arrays(int arr[100] , int arrlength)
{
    int sum =0 ;
    
    for(int i=0 ; i<arrlength ; i++)
    {
        sum += arr[i] ;
    }
    
    return sum ;
    
    
}

float average_of_arrays(int arr[100] , int arrlength)
{
    return (float)sum_of_random_arrays(arr , arrlength) / arrlength ;
}

int main()
{
    
    srand((unsigned)time(NULL)) ;
    
    int arr[100] , arrlength ;
    
    read_arrays(arr , arrlength) ;
    
    
    cout << "\n original array : " ;
    print_arrays(arr , arrlength) ;
    
    cout << "\n the average  of this random arrays  =  " ;
    cout << average_of_arrays(arr , arrlength) ;
    
    return 0;
}




