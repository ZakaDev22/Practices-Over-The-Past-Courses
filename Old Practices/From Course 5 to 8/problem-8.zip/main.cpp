

#include <iostream>

using namespace std;
                                            // my solution


int readpositivenumber(string message)
{
    int number ;
    
    cout << message << endl;
    cin  >> number ;
    
    return number ;
}

void print_frequince_of_n(int number)
{
    int remainder = 0 ;
    
    int sum = 0 ;
    
    int num = 0 ;
    
    int freqince = 2 ;
    
    do
    {
        remainder = number % 10 ;
        number = number / 10 ;
        
        num = remainder ;
        
        if(num == 2)
        {
            sum++ ;
        }
        
        
    }while(number > 0);
    
    cout << "\n\n \t frequince of the number 2 limits = " << sum ;
}

int main()
{
      
       print_frequince_of_n(readpositivenumber("please enter a positive number"));

    return 0;
}
