#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;

string TrimLeft(string s1)
{
	
	for (short i = 0; i < s1.length(); i++)
	{
		if(s1[i] != ' ')
		{
			return s1.substr(i, s1.length() - i);
		}

	}
	return "";
}

string TrimRight(string s1)
{
	for (short i = s1.length() - 1; i >= 0; i--)
	{
		if (s1[i] != ' ')
		{
			return s1.substr(0, i + 1);
		}
	}

	
	return "";

}

string Trim(string s1)
{
	
	return TrimLeft(TrimRight(s1));
}


int main() 
{

	// zaka#.#ssiya#.#wolf#.#caty.

	string s1 = "     zaka#.#ssiya#.#wolf#.#caty.   az  ";


	cout << "\n Trim Left = " << TrimLeft(s1) << endl;

	cout << "\n Trim Right = " << TrimRight(s1) << endl;

	cout << "\n Trim  = " << Trim(s1) << endl;


	return 0;
}