#include <iostream>

#include <vector>

using namespace std;



int main()
{
	
	vector <int>  num { 21,2,23,11 };

	cout << "\n initial vector :  " ;

	for (const int & vNumbers : num)
	{
		cout << vNumbers << " ";
	}
	cout << endl << endl;
		
	cout << "\n\n update vector : \n";

	for ( int& i : num)
	{
		i = 21;
		cout << i << " ";
	}

	cout << "\n\n=================================\n\n";

	num[0] = 11;
	num[1] = 10;
	num.at(2) = 21;
	num.at(3) = 23;

	cout << "\n\n update vector : \n";
	for ( int& i : num)
	{
		cout << i << " ";
	}

	printf("\n\n\n");

	return 0;
}

