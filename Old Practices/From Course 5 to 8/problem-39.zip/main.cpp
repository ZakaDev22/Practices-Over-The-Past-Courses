#include <iostream>
#include <cmath>
#include <cstdlib>

using namespace std ;

enum enPrimeNumber { prim=1 , notprim=2};

enPrimeNumber CheckPrimeNumber(int number)
{
    int num = round(number/2) ;
    
    for(int count =2 ; count <= num ; count++)
    {
        
    if(number%count == 0)
        return enPrimeNumber::notprim ;
    
    }
    
    return enPrimeNumber::prim ;
}

int readrandom(int from , int to)
{
    int n = rand() % (to - from + 1) + from ;
    
    return n ;
}

void read_arrays(int arr[100] , int& arrlength)
{
    cout << "\n enter how many ilements do you want \n";
    cin>> arrlength ;
    
    for(int i=0 ; i<arrlength ; i++)
    {
        arr[i] = readrandom(1,100);
    }
    cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
    
    for(int i=0 ; i<arrlength ; i++)
    {
        cout << arr[i] << " " ;
    }
    cout << endl;
}

void addarrayilements(int number , int arr[100] , int& arrlength)
{
    arrlength++ ;
    
    arr[arrlength - 1] = number;
}

void copyonlyprimnumber(int arrsource[100] , int arrdistination[100], int arrlength , int& arrlength2)
{
  
  for(int i=0 ; i<arrlength ;i++)
  {
      if(CheckPrimeNumber(arrsource[i]) == enPrimeNumber::prim)
      {
       addarrayilements(arrsource[i],arrdistination,arrlength2);  
      }
  }
   
}

int main()
{
    srand((unsigned)time(NULL));
   
   int arr[100] , arrlength ; 
   
   read_arrays(arr , arrlength);
   
   cout << "\n array 1 ilements : ";
   print_arrays(arr , arrlength) ;
   
   int arr2[100]  ,  arrlength2=0 ;
   
   copyonlyprimnumber(arr , arr2 , arrlength , arrlength2);
   
   cout << "\n prim numbers in array 1 : ";
   print_arrays(arr2 , arrlength2) ;
   
   
   
    
    return 0;
}







