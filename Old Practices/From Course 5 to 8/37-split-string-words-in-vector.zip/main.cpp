#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;


vector <string> SplitString( string s1 , string delim )
{
	vector <string> vWords;

	short pos = 0;

	string sWord; 

	while ( (pos = s1.find(delim)) != std::string::npos)
	{
		sWord = s1.substr(0, pos);

		if (sWord != "")
		{
			vWords.push_back(sWord);

		}
		s1.erase(0, pos + delim.length());
	}
	
	if (sWord != "")
	{
		vWords.push_back(s1); 
	}

	return  vWords;
}

int main() 
{

	// zaka#.#ssiya#.#wolf#.#caty.


	string delim = " ";

	vector <string> vWords;

    vWords =	SplitString(mylib::readstring(), "#.#");

	cout << "\n Tokens = " << vWords.size() << endl;

	for (string& words : vWords)
	{
		cout << words << endl;
	}


	return 0;
}