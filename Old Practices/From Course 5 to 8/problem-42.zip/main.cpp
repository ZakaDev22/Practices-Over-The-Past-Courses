#include <iostream>
#include <cstdlib>

using namespace std ;

int readrandom(int from , int to)
{
    int n = rand() % (to - from + 1) + from ;
    
    return n ;
}

void read_arrays(int arr[100] , int& arrlength)
{
    cout << "\n enter how many ilements do you want \n";
    cin>> arrlength ;
    
    for(int i=0 ; i<arrlength ; i++)
    {
        arr[i] = readrandom(1,100);
    }
    cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
    
    for(int i=0 ; i<arrlength ; i++)
    {
        cout << arr[i] << " " ;
    }
    cout << endl;
}


short count_how_many_odd_numbers_in_array(int arrsours[100], int arrlength )
{
  short SumOfOddNumbers =0;
  
  for(int i=0 ; i<arrlength ;i++)
  {
      if(arrsours[i] % 2 != 0)
      {
        SumOfOddNumbers++;
      }
  }
  
  return SumOfOddNumbers;
}

int main()
{
    srand((unsigned)time(NULL));
   
   int arr[100] , arrlength ; 
   
   read_arrays(arr , arrlength);
   
   
    cout << "\n array 1 ilements : ";
   print_arrays(arr , arrlength) ;
   
   cout << "\n odd numbers in array 1 : " << count_how_many_odd_numbers_in_array(arr,arrlength) ;
   
   
   
   
    
    return 0;
}



