#include <iostream>

#include <cmath>

using namespace std ;

enum enprimnotprim { prim=1 , notprim=2};

int readpositivnumber(string message)
{
    int number = 0 ;
    
    do
    {
        cout << message << endl;
        cin >> number ;
        
    }while(number < 0) ;
    
    return number ;
    
}

enprimnotprim checknnumberprime(int number)
{
    int num = round(number/2) ;
    
    for(int i=2 ; i<=num ;  i++)
     {
       if(number  % i  == 0)
        return enprimnotprim::notprim ;
        
     }
     
    return enprimnotprim::prim ;
    
}

void printresults(int number)
{
    cout << endl;
    cout << " all the prim numbers forom " << 1 << " to " << number ;
    cout <<  " are : " << endl;
    
    for(int i=1 ; i<=number ; i++)
    {
        if(checknnumberprime(i)== enprimnotprim::prim)
        
            cout << i << endl;
    }
}

int main()
{
    
  printresults(readpositivnumber("please enter a positive number"));
  
    return 0;
}








