#include <iostream>
#include <cstdlib>
#include <iomanip>
              
using namespace std;

short ReadRandomNumbers(short from, short to)
{
	short num = rand() % (to - from + 1) + from;

	return num;
}

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{


	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr[i][j] = ReadRandomNumbers(1, 10);
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			printf(" %0*d ", 2, arr[i][j]);
		}
		cout << endl;
	}
}

short SumofMatrix(int arr[3][3], short rows, short cols)
{
	short sum = 0;

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			sum += arr[i][j];
		}
	}

	return sum;
}

int main()
{
	srand((unsigned)time(NULL));

	int matrix[3][3];


	FillMatrixRandom3x3Numbers(matrix, 3, 3);

	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix, 3, 3);

	cout << "\n the sum of Matrix is : ";
	cout << SumofMatrix(matrix, 3, 3);

	cout << "\n";


	return 0;
}
