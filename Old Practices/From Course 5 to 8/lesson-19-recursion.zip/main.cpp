#include <iostream>

using namespace std;



void PrintFromNtoM(short n, short m) 
{
	if (n <=  m)
	{
		cout << n << "  ";

		PrintFromNtoM(n + 1, m);
	}
}

int main() {

	PrintFromNtoM(1, 21);

	return 0;
}