#include <iostream>

using namespace std;

string readpassword(string message)
{
    string password ="";
    
    cout << message << endl;
    cin >> password ;
    
    return password ;
}

void print_all_words_AAA_to_ZZZ()
{
     
     string password =  readpassword("plase enter your password : ") ;
   
     string words ="";
    
    int num = 0;
    
   for(int i =65 ; i <= 90 ; i++)
   {
      for(int z=65 ; z<=90 ; z++)
      {
          
          for(int s=65 ; s<=90 ; s++)
          {
            words = char(i) ;
            words += char(z);
            words += char(s);
            
            cout << words << endl;
            
            num++ ;
            
            if(words == password)
            {
                 cout << "\n\t\t your password is AAF " << endl;
                 cout << "\n\t\t found after " << " [" <<num<< "] trial " << endl;
                
                break ;
            }
            
            words ="";
            
          }
         
         if(words == password)
            {
                break ;
            }
      }
      
        if(words == password)
             {
              
                break ;
             }
   }
 
}

int main()
{
 
  print_all_words_AAA_to_ZZZ();
    
    return 0;
}