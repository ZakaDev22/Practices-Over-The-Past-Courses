#include <iostream>


using namespace std ;
                                                            // my solution
int readthenumber(string message)
{
    int number;
    
    cout << message << endl;
    cin >> number ;
    
    return number;
}

int printreversdnumbers( int number  )
{
   int remaindr = 0 ; 
   
   int number2 = 0; 
   
   while(number > 0)
   {
       remaindr = number % 10 ;
       number = number /10 ;
       number2 = number2 * 10 + remaindr ;
   }
   
   return number2 ;
}

void print_palandrom_number(int number)
{
    if(printreversdnumbers(number) == number)
     cout << " yes , it palindrome number ";
     
    else
      cout << " no it not a palindrome number" ;
}

int main()
{
    print_palandrom_number(readthenumber("plase enter a positiv number"));

   return 0; 
}


