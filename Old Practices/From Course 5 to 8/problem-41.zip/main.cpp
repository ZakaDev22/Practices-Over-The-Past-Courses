#include <iostream>

using namespace std;


void fill_arrays(int arr[100] , int& arrlength)
{
   arrlength =6;
    
    arr[0]=10;
    arr[1]=20;
    arr[2]=30;
    arr[3]=30;
    arr[4]=20;
    arr[5]=10;
}

void print_arrays(int arr[100] , int arrlength)
{
   
    
    for(int i=0 ; i<arrlength ; i++)
    {
       cout << arr[i] << " ";
    }
    cout << endl;
}

bool is_Palandrome_Array(int arr[100],int arrlength)
{
    for(int i=0;i<arrlength;i++)
    {
        if(arr[i] != arr[arrlength - i - 1])
         return false ;
    }
    
    return true ;
}

int main()
{
  int arr[100] , arrlength =0 ;
  
  fill_arrays(arr,arrlength);
  
  
  cout << " \n\t array 1 ilements : ";
  print_arrays(arr,arrlength);
  
   if(is_Palandrome_Array(arr,arrlength))
    cout << "\n\t yes , its a palandrome array "<<endl;
    
    else
     cout << " \n\t no , its not a palandrome array " << endl;
    
    return 0;
}





