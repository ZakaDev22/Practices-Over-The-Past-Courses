#include <iostream>

using namespace std;


int main()
{

	short x[10][10];

	for (short i = 1; i <= 10; i++)
	{

		for (short j = 1; j <= 10; j++)
		{
			x[i][j] = i  * j  ;

		}
		cout << endl;
	}


	for (short i = 1; i <= 10; i++)
	{

		for (short j = 1; j <= 10; j++)
		{
			 short s = x[i][j];

			 printf(" %0*d ",2, s);

			//cout << "\t" << x[i][j] << " ";
		}
		cout << endl;
	}

	
	return 0;
}



