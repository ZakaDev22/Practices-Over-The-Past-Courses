#include <iostream>

#include <cstdlib>
                                            //   my solution
using namespace std ;

int ReadPositivNumber(string message)
{
    int num=0;
    
    cout << message << endl;
    cin >> num ;
    
    return num;
}

int readrandomnumber(int from , int to)
{
    int number = rand() %  (to - from + 1) + from ;
    
    return number ;
}

void read_arrays(int arr[100] , int arrlength)
{
    
     for(int i=0 ; i<arrlength ; i++)
     {
         arr[i] = readrandomnumber(1,100) ;
     }
     cout << endl;
}

void print_arrays(int arr[100] , int arrlength)
{
   
    for(int i=0 ; i<arrlength ; i++)
     {
         cout << arr[i] << " " ;
     }
     
     cout << endl;
}

void copy_array_1_in_revesed_order(int arr[100] , int arr2[100] , int arrlength)
{
   int count = arrlength ;
   
   for(int i=0 ; i<arrlength;i++)
   {
       count--;
       arr2[i] = arr[count] ;
       
   }
   cout << endl;
    
    
}

int main()
{
    
    srand((unsigned)time(NULL)) ;
    
    int arr[100]  ;
    int arrlength = ReadPositivNumber("enter how many ilements do you want");
    
    read_arrays(arr , arrlength) ;
    
    int arr2[100] ;
    copy_array_1_in_revesed_order(arr , arr2 , arrlength);
    
    cout << "\n  array 1 ilements  : \n " ;
    print_arrays(arr , arrlength) ;
    
    cout << "\n  array 2 ilements after copying array 1 in reversed order  :  \n" ;
    print_arrays(arr2 , arrlength) ;
    
    return 0;
}




