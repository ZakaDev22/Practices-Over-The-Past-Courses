#include <iostream>
#include <string>
#include <cctype>

using namespace std;

char readChar()
{
	char s;

	cout << " please enter a character you want to invert! " << endl;
	cin >> s;
	return s;
}

char invertCharacters(char letter)
{
	return isupper(letter) ? tolower(letter) : toupper(letter);
}

void InvertItsCase()
{
	char letter = readChar() ;

	cout << "\n char befor inverting :  ";
	cout << letter << endl;

	letter = invertCharacters(letter);

	cout << "\n char after inverting :  ";
	cout << letter  << endl;
}

int main() {

	
	InvertItsCase();
	

	return 0;
}