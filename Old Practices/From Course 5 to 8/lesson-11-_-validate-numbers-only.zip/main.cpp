#include <iostream>

using namespace std ;

int readOnlyNumbers()
{
    int number =0;
    
    cout << "\n please enter a number : " << endl;
    cin >> number;
    
    while(cin.fail())
    {
        cin.clear();
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
        
        cout << "invalid number, enter a valid one ! " << endl;
        cin >> number;
    }
    
    return number;
    
}

int main()
{
    
  cout <<   readOnlyNumbers();
    
    return 0;
}


