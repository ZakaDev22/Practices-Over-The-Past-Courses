#include <iostream>

#include <cstdlib>

using namespace std ;

int readrandom(int from , int to)
{
    int randonumber = rand() % (to - from + 1 ) - from ;
    
    return randonumber ;
}

void read_array(int arr[100] , int& arrlength)
{
    cout << "\n enter how many ilements do you want \n";
    cin >> arrlength ;
    
     for(int i=0 ; i<arrlength ; i++)
     {
         arr[i] = readrandom(1,100) ;
     }
     cout << endl;
    
}

void print_array(int arr[100] , int arrlength)
{
    for(int i=0 ; i<arrlength ; i++)
    {
        cout << arr[i] << " " ;
    }
    cout << endl;
}


int main()
{
    srand((unsigned)time(NULL));
    
    int arr[100] , arrlength  ;
    
    read_array(arr , arrlength) ;
    
    
    cout << "\n\t original array : " ;
    print_array(arr , arrlength) ;
    
    
    return 0;
}

