#include <iostream>

#include "mysum.h";

using namespace std;


int main() {

	short page = 1, totalPages = 10;

	printf("the page number = %d \n" , page);

	printf("you are in page %d of %d \n ", page, totalPages);

	printf("the page number = %0*d  \n", 2, page);
	printf("the page number = %0*d  \n", 3, page);
	printf("the page number = %0*d  \n", 4, page);
	printf("the page number = %0*d  \n", 21, page);

	short num1 = 21, num2 = 23;

	printf("sum of wolf age + caty age , %d + %d = %d \n ", num1, num2, mysum::MySum(num1, num2));

	return 0;
}