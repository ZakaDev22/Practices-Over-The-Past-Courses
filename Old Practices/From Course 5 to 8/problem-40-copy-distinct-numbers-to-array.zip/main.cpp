#include <iostream>

using namespace std;

void fill_array(int arr[100] , int& arrlength)
{
   arrlength = 10 ;
   
   arr[0] = 10 ;
   arr[1] = 10 ;
   arr[2] = 10 ;
   arr[3] = 50 ;
   arr[4] = 50 ;
   arr[5] = 70 ;
   arr[6] = 70 ;
   arr[7] = 70 ;
   arr[8] = 70 ;
   arr[9] = 90 ;
}

void print_Arrays(int arr[100] , int arrlength)
{
   
    for(int i=0 ; i<arrlength ; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}

short findthenumberposition(int number , int arrdestination[100] , int arrlength)
{
    for(int i=0 ; i<arrlength ;i++)
    {
        if(arrdestination[i] == number)
        return i ;
    }
    
    return -1 ;
}

bool isfoundnumber(int number,int arrdestination[100] , int arrlength) 
{
   return findthenumberposition(number , arrdestination , arrlength) != -1 ;
}

void addarrayilementsin_second_array(int number ,int arrdestination[100] ,int& arrlength2 )
{
   
    arrlength2++ ;
   
   arrdestination[arrlength2-1] = number ;
}

void copyonlydestincenumbers(int arrsours[100],int arrdestination[100] ,int arrlength , int& arrlength2)
{
    for(int i=0 ; i<arrlength ;i++)
    {
        if( !isfoundnumber(arrsours[i],arrdestination,arrlength) )
        {
            addarrayilementsin_second_array(arrsours[i],arrdestination,arrlength2);
        }
    }
}

int main()
{
  int arr[100] , arrlength=0 , arrdestination[100] , arrlength2=0;
  
  fill_array(arr , arrlength);
  
   copyonlydestincenumbers(arr,arrdestination,arrlength,arrlength2);
   
   cout << "\n\t array 1 ilements : ";
   print_Arrays(arr,arrlength);
   
   cout << "\n\t array 2 only destince numbers : ";
   print_Arrays(arrdestination,arrlength2);
    
    return 0;
}





