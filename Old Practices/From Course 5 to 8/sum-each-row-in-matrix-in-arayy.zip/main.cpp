#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

int  readrandnumber(int from, int to)
{
	//  functionto generate random number

	int reandnum = rand() % (to - from + 1) + from;

	return  reandnum;
}

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr[i][j] = readrandnumber(1, 100);
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			cout << setw(3) << arr[i][j] << "   ";
		}
		cout << endl;
	}
}

short RowSum(int arr[3][3], short rownumber, short cols)
{
	short sum = 0;

	for (short j = 0; j <= cols - 1; j++)
	{
		sum += arr[rownumber][j];
	}

	return sum;
}

void FillsumOfEachRowInArray(int arr[3][3], short rows, short cols ,int arr1[3])
{

	for (short i = 0; i < rows; i++)
	{
		
		arr1[i] = RowSum(arr , i , cols) ;
		
	}
}


void print_Arrays(int arr[3], int arrlength)
{
	cout << "\n the following is sum of each row of the matrix in one Dm Array \n\n";

	for (int i = 0; i < arrlength; i++)
	{
		cout << " array element number [" << i + 1 << "] is : " << arr[i] << endl;
	}
	cout << "\n";
}

int main()
{
	srand((unsigned)time(NULL));

	int arr[3][3];

	int arr1[3];

	FillMatrixRandom3x3Numbers(arr, 3, 3 );


	cout << "\n the following is 3x3 random matrix  \n\n";

	PrintMatrixRandom3x3Numbers(arr, 3, 3 );

	FillsumOfEachRowInArray(arr, 3, 3, arr1);

	print_Arrays(arr1, 3);


	return 0;
}