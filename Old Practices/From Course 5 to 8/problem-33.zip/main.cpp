#include <iostream>

#include <cstdlib>
                                                        //   #33 my solution                    
using namespace std ;

enum randomcharacter {smallletters=1 , capitalletters=2 , specialchar=3 , digits=4};

int readrandom(int from , int to)
{
    int randomnumber = rand() % (to - from + 1) +from ;
    
    return randomnumber ;
}

char getradomcharacters(randomcharacter characterstype)
{
    switch(characterstype)
    {
        case randomcharacter::smallletters :
        return char(readrandom(97,122));
        break;
        
        case randomcharacter::capitalletters:
        return char(readrandom(65,90));
        break;
        
        case randomcharacter::digits :
        return char(readrandom(48,57));
        break;
        
        case randomcharacter::specialchar :
        return char(readrandom(33,47));
        break;
    }
    
    return characterstype ;
}

string get_4_letters(randomcharacter characterstype , short length)
{
    string word ;
    
    for(int i=1 ; i<=length ; i++)
    {
        word = word + getradomcharacters(characterstype) ;
    }
    
    return word ;
}

string get_full_key()
{
    string key ="";
    
    key = get_4_letters(randomcharacter::capitalletters , 4) + "-" ;
    key += get_4_letters(randomcharacter::capitalletters , 4) + "-";
    key += get_4_letters(randomcharacter::capitalletters , 4) + "-";
    key += get_4_letters(randomcharacter::capitalletters , 4) ;
    
    return key ;
}

void readarrays(string arr[100] , int& length)
{
    cout << " enter how meny arrays do you want ! " << endl;
    cin >> length ;
    
    for(int i=0 ; i<length ; i++)
    {
        arr[i] = get_full_key();
    }
    cout << endl;
    
}

void printarrays(string arr[100] , int length)
{
    
    for(int i=0 ; i<length ; i++)
    {
        cout << "array ["<<i+1<< "} : " << arr[i] << endl;
    }
    cout << endl;
    
}

int main()
{
    srand((unsigned)time(NULL));
    
    string arr[100] ; int length ;
    
  
    readarrays(arr , length);
    
    printarrays(arr , length);
    
  
    
    
    return 0;
}







