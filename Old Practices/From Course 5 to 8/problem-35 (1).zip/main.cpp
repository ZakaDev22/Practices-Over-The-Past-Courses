#include <iostream>
#include <cstdlib>

using namespace std ;

int readrandom(int from , int to)
{
    int number= rand() % (to - from + 1 )+from ;
    
    return number ;
}

int readnumber()
{
    int num=0;
    
    cout << " please enter a  number you want to check : " << endl;
    cin >> num ;
    
    return num;
}

void Read_Arrays(int arr[100] , int& arrlength)
{
    cout << " please enter how many ilements do you want in arrays! : " << endl;
    cin >> arrlength ;
    
    for(int i=0 ; i<arrlength ; i++)
    {
        arr[i] = readrandom(1,100);
    }
    cout << "\n";
}

void print_Arrays(int arr[100] , int arrlength)
{
   
    for(int i=0 ; i<arrlength ; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}

short findthenumberposition(int arr[100] , int arrlength , int numbertocheck)
{
    for(int i=0 ; i<arrlength ;i++)
    {
        if(arr[i] == numbertocheck)
        return i ;
    }
    
    return -1 ;
}

bool isfoundnumber(int arr[100],int arrlength , int numbertocheck) 
{
   return findthenumberposition(arr , arrlength , numbertocheck) != -1 ;
}

int main()
{
    srand((unsigned)time(NULL));
    
    int arr[100] , arrlength ;
    
    Read_Arrays(arr , arrlength);
    
    cout << "\n\t array ilements : ";
    print_Arrays(arr , arrlength);
    
    int numbertocheck = readnumber();
    cout << "\n\t the number you want to check is " << numbertocheck << endl;
    
   
    if(isfoundnumber(arr,arrlength , numbertocheck))  
        cout << "\n\tyes, the number is found :-)"<< endl;
     
     else
        cout << "\n\t no, the number is not found :-("<<endl;
    
    
    return 0;
}





