#include <iostream>
#include <cmath>

using namespace std ;

float getFractionPart(float number)
{
  return number - (int)number ;    
}

float readnumber(string message)
{
    float number=0;
    
    cout << message << endl;
    cin >> number ;
    
    return number ;
}

int my_round_result(float number)
{
    int intPart;
    
    intPart= (int)number;
     
     float fractionpart = getFractionPart(number);
    
    if(abs(fractionpart) > 0.5)
    {
        if(number > 0)
         return ++intPart;
         
        else
         return --intPart;
    }
    
    else
     return intPart;
    
}

int main()
{
  float number =  readnumber(" enter a number ");
    
   
    cout << "\n\t my round function : " << my_round_result(number) << endl;
  
   cout << "\n\t c++ round result : " << round(number) ;
   
   
   
    
    return 0;
}







