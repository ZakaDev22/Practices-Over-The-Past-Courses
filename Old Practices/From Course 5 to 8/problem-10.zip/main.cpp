

#include <iostream>

using namespace std;
                                            // teacher solution


int readpositivenumber(string message)
{
    int number ;
    
    cout << message << endl;
    cin  >> number ;
    
    return number ;
}

int reverednumber( int number)
{
   int remaindr = 0 ;
   int number2 = 0 ;
   
   
   while(number > 0)
   {
       remaindr = number % 10 ;
       number = number /10 ;
       number2 = number2 * 10 + remaindr ;
   }

   return number2 ;
}

void printorderfromlefttoright(int number)
{
    int remainder = 0;
    
    while(number > 0)
    {
        remainder = number % 10 ;
        number = number / 10 ;
        
        cout << remainder << endl;
    }
}

int main()
{
      printorderfromlefttoright( reverednumber(readpositivenumber(" please enetr a positiv number"))) ;
      
    return 0;
}
