#include <iostream>

using namespace std;



int main()
{
	int a = 10;

	cout << " a value = " << a << endl;
	cout << " a adresse = " << &a << endl;

	int* ptr ;
	ptr = &a;

	cout << " pointer value = " << ptr << endl;
	cout << "  value of hte adresse that ptr pointing to is : " << *ptr << endl;

	*ptr = 21;

	cout << a << endl;
	cout << *ptr << endl;

	*ptr = 23;

	cout << a << endl;
	cout << *ptr << endl;

	return 0;
}
