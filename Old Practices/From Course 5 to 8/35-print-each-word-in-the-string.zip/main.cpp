#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>

#include "MyStringLib.h" 

using namespace std;


void PrintEachWordInTheString(string s1)
{
	string delim = " "; // delimiter

	cout << "\n your string words is : \n\n";

	short pos = 0;

	string sWord; // define a string variabel.

	// use find() function to get the position of the delimiter
	while ( (pos = s1.find(delim)) != std::string::npos)
	{
		sWord = s1.substr(0, pos); // stor the word.

		if (sWord != "")
		{
			cout << sWord << endl;;
		}

		s1.erase(0, pos + delim.length()); /* erase() until position end move to next word */
	}
	
	if (sWord != "")
		cout << s1 << endl; // print last word of the string
}

int main() 
{

	// Mohammed Abu-Hadhoud @ProgrammingAdvices.

	PrintEachWordInTheString(mylib::readstring());



	return 0;
}