#include <iostream>

using namespace std;

short functional(short& num)
{
	 return num++;
}

int main()
{
	short num1 = 10;

	cout << num1 << endl;
	cout << &num1 << endl;

	cout << functional(num1);

	cout << " number w by ref : " << num1 << endl;


	return 0;
}