#include <iostream>
#include <iomanip>

using namespace std;


void PrintMatrixRandom3x3Numbers(int matrix[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			cout << setw(3) << matrix[i][j] << " ";
		}
		cout << endl;
	}
}


bool checkIstheNumberExistsintheMatrix(int matrix[3][3], short checknum , short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			if (matrix[i][j] == checknum)
				return true;
		}
	}
	return false;
}

int main()
{

	int matrix[3][3] = { {0,9,0} , {2,0,11} ,{10,0,0} };


	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix, 3, 3);

	short num = 0;

	cout << "\nplease enter the number you want to check ! \n";
	cin >> num;

	if (checkIstheNumberExistsintheMatrix(matrix, num , 3, 3))
	{
		cout << "\n yes it is there \n";
	}

	else
		cout << "\nno it not there \n";


	return 0;
}

