#include <iostream>

using namespace std;

int main()
{
	// declare an int pointer
	int *ptrz;

	// declare a float pointer
	float* ptrs;

	// dynamically allocate memory
	ptrz = new int;
	ptrs = new float;

	// assigning value to the memory
	*ptrz = 21;
	*ptrs = 23;


	cout << *ptrz << endl;
	cout << *ptrs << endl;

	// deallocate the memory
	delete new int;
	delete new float;

	return 0;
}

