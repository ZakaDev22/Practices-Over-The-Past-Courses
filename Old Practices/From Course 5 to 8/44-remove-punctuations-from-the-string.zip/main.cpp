#include <iostream>
#include <cctype>
#include <string>
#include <iomanip>

//#include "MyStringLib.h";

using namespace std;


string  removePunctution(string s1)
{
	string s2 = "";

	for (short i = 0; i < s1.length(); i++)
	{
		if (!ispunct(s1[i]))
		{
			s2 += s1[i];
		}
	}

	return s2;
}

int main()
{
	// welcom to jordan, jordan is a nice country; it`s amazing.

	string s1 = "welcom to jordan, jordan is a nice country; it`s amazing.";

	cout << "\n string befor punct : " << s1 << endl;

	cout << "\n string after punct : " << removePunctution(s1) << endl;

		return 0;
}