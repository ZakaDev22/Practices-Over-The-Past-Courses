#include <iostream>

using namespace std;


void print_all_words_AAA_to_ZZZ()
{
    
   for(int i =65 ; i <= 90 ; i++)
   {
      for(int z=65 ; z<=90 ; z++)
      {
          for(int s=65 ; s<=90 ; s++)
          {
             cout << char(i) << char(z) << char(s) <<endl; 
          }
          cout << "************************************************\n";
      }
   }
   
}

int main()
{
    print_all_words_AAA_to_ZZZ();
    
    
    return 0;
}