#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;


string JoinString(string array[4] , short lenght , string delim)
{
	string s1 = "";

	for (short i = 0; i < lenght; i++)
	{
		s1 += array[i] + delim;
	}

	return s1.substr(0, s1.length() - delim.length());
}


string JoinString(vector <string> vwords , string delim)
{
	string s1;

	for (string & words : vwords)
	{
		s1 += words + delim;
	}

	return s1.substr(0, s1.length() - delim.length());
}

int main() 
{

	vector <string> vwords = { "zaka", "ssiya", "wolf" , "caty" };

	string array[] = { "zaka", "ssiya", "wolf" , "caty" };


	cout << "\n vector after join in the string = ";
	
	cout << JoinString(vwords, " ## ") << endl;

	// join string using arrays.

	cout << "\n array after join in the string = ";

	cout << JoinString(array,4 , " # ") << endl;   // using the same name of vector function (overloading).

	return 0;
}