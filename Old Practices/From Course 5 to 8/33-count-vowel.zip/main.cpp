#include <iostream>
#include <string>
#include <cctype>

#include "MyStringLib.h" 

using namespace std;


bool IsVowel(char char1)
{
	char1 = tolower(char1);
	
	return (('a' == char1) || ('i' == char1) || ('o' == char1) || ('e' == char1) || ('u' == char1));
}

short countVowelInString(string s1)
{
	short count = 0;

	for (int i = 0; i < s1.length() ; i++)
	{
		if (IsVowel(s1[i]))
			count++;
	}

	return count;
}


int main() {

	//  Programming ADvices.
	
	string s1 = mylib::readstring();
	
	cout << "\n  number of vowel in the string is = " << countVowelInString(s1) << endl;


	return 0;
}