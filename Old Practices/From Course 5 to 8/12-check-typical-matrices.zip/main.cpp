#include <iostream>
#include <cstdlib>
#include <iomanip>
              
using namespace std;

short ReadRandomNumbers(short from, short to)
{
	short num = rand() % (to - from + 1) + from;

	return num;
}

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{
	short count = 0;

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr[i][j] = ReadRandomNumbers(1, 10);
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			printf(" %0*d ", 2, arr[i][j]);
		}
		cout << endl;
	}
}

short SumofMatrix(int arr[3][3], short rows, short cols)
{
	short sum = 0;

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			sum += arr[i][j];
		}
	}

	return sum;
}

bool IsmatrecesEqual(int matrix[3][3], int matrix2[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			if (matrix[i][j] == matrix2[i][j])
			{
				return true;
			}
		}
	}
	return false;
}

int main()
{
	srand((unsigned)time(NULL));

	int matrix[3][3];
	int matrix2[3][3];


	FillMatrixRandom3x3Numbers(matrix, 3, 3);
	FillMatrixRandom3x3Numbers(matrix2, 3, 3);

	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix, 3, 3);
	cout << "\n the sum of Matrix 1 is : ";
	cout << SumofMatrix(matrix, 3, 3);
	
	cout << "\n\n Matrix 2 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix2, 3, 3);
	cout << "\n the sum of Matrix 2 is : ";
	cout << SumofMatrix(matrix2, 3, 3);
	


	if (IsmatrecesEqual(matrix, matrix2, 3, 3) )
	{
		cout << "\n\n\t yes : the matrices is equal \n";
	}
	else
		cout << "\n\n\t No : matrices are not equal \n";



	return 0;
}
