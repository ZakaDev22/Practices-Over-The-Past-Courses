#include <iostream>

using namespace std;

int readnumber()
{
    int number=0;
    
    cout << "please enter a number : " << endl;
    cin >> number;
    
    return number;
}

void addarrayilements(int number , int arr[100] , int& arrlength)
{
    arrlength++ ;
    
    arr[arrlength - 1] = number;
}

void unputusernumbersinarray( int arr[100], int& arrlength)
{
    bool addmor = true;
    
    do
    {
        addarrayilements(readnumber(),arr,arrlength);
        
        cout << "do you like to add mor numbers [0]:no , [1}:yes " << endl;
        cin >> addmor ;
        
    }while(addmor);
    
}

void print_arrays(int arr[100] , int arrlength)
{
    for(int i=0;i<arrlength;i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main()
{
    int arr[100] , arrlength=0;
    unputusernumbersinarray(arr,arrlength);
    
    cout << "\n\t array length : " << arrlength << endl;
    
    cout << " \n\t arrays ilements : " ;
    print_arrays(arr,arrlength);
    
    return 0;
}




