
#include <iostream>

#include <cmath>
                                                                //   my solution for problem #3
using namespace std;

enum enperfectnotperfect{perfect=1 , notperfect=2};

int readpositivnumber(string message)
{
    int number = 0 ;
    
    do
    {
         cout << message << endl;
         cin >> number ;
        
    }while(number < 0 );
    
    return number ;
}

enperfectnotperfect checkperfectnumbers(int number)
{
    int num = round(number/2) ;
    
    int sum =0 ;
    
    for(int i=1 ; i<=num ; i++)
    {
     
     if(number % i == 0)
     {
         sum += i ;
     }
        
    }
    
    if(sum == number)
     return enperfectnotperfect::perfect ;
     
    else 
      return enperfectnotperfect::notperfect ;
}

void print_perfect_number(int number)
{
    if(checkperfectnumbers(number) == enperfectnotperfect::perfect)
     cout << " the number " << number << " is perfect \n";
     
    else
     cout << " the number " << number << " is not perfect " << endl;
}

int main()
{
    print_perfect_number(readpositivnumber("please enter a positiv number"));

    return 0;
}
