#include <iostream>
#include <string>
#include <cctype>

using namespace std;

string readString()
{
	string s;

	cout << "\n please enter the string you want to invert! \n";
	getline(cin, s);

	return s;
}

enum enWhatToCount { smallLetters = 0, capitaLetters=1 , all=2 };

short countall( string s1 ,enWhatToCount WhatToCount= enWhatToCount::all)
{

	if (WhatToCount == enWhatToCount::all)
	{
		return s1.length();
	}

	short counter = 0;

	for (short i = 0; i < s1.length(); i++)
	{
		if (WhatToCount == enWhatToCount::capitaLetters && isupper(s1[i]))
			counter++;

		if (WhatToCount == enWhatToCount::smallLetters && islower(s1[i]))
			counter++;

	}
	return counter;

}

short CountSmallLetters(string s1)
{
	short small = 0;

	for (short i = 0; i < s1.length(); i++)
	{
		if (islower(s1[i]))
			small++;
	}
	return small;
}

short CountCapitalLetters(string s1)
{
	short capital = 0;

	for (short i = 0; i < s1.length(); i++)
	{
		if (isupper(s1[i]))
			capital++;
	}
	return capital;
}

int main() {

	// Mohammed Abu-Hadhoud

	string s1 = readString();
	
	cout << "\n string lenght = " << s1.length() << endl;
	cout << "\n count of capital letters  = " << CountCapitalLetters(s1) << endl;
	cout << "\n count of small letters  = " << CountSmallLetters(s1) << endl;

	cout << "\n method 2 \n ";

	cout << "\n string lenght = " << countall(s1) << endl;
	cout << "\n count of capital letters  = " <<countall(s1,enWhatToCount::capitaLetters) << endl;
	cout << "\n count of small letters  = " << countall(s1, enWhatToCount::smallLetters) << endl;
	
	return 0;
}