#include <iostream>
#include <iomanip>

using namespace std;

void PrintMatrixRandom3x3Numbers(int matrix[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			cout << setw(3) << matrix[i][j] << " ";
		}
		cout << endl;
	}
}

short maxNumberinMatrix(int matrix[3][3], short row, short col)
{
	short num = matrix[0][0];

	for (short i = 0; i < row; i++)
	{
		for (short j = 0; j < col; j++)
		{
			if (matrix[i][j] > num)
			{
				num = matrix[i][j];
			}
		}
		
	}
	  return num;
}

short minNumberinMatrix(int matrix[3][3], short row, short col)
{
	short num = matrix[0][0];

	for (short i = 0; i < row; i++)
	{
		for (short j = 0; j < col; j++)
		{
			if (num > matrix[i][j])
			{
				num = matrix[i][j];
			}
		}

	}
	return num;
}

void PrintMax_MinNumberintheMatrix(int matrix[3][3],short row,short col)
{
	cout << "\n the max number in the matrix is : " << maxNumberinMatrix(matrix, row, col);

	cout << "\n the min number in the matrix is : " << minNumberinMatrix(matrix, row, col);
}


int main()
{

	int matrix[3][3] = { {2 ,11,0} , {-2,21,121} ,{7,99,44} };
	


	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix, 3, 3);

	PrintMax_MinNumberintheMatrix(matrix, 3, 3);

	

	cout << endl;

	return 0;
}

