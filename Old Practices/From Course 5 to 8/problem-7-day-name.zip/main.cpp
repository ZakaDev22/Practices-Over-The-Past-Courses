#include <iostream>

#include <string>
#include <vector>
#include <cctype>

using namespace std;

short ReadNumbers(string message)
{
	short n = 0;

	cout << message;
	cin >> n;

	return n;
}

short CulculateTheOrderDay(short Year, short Month, short Day)
{
	short a = ((14 - Month) / 12);

	short y = Year - a;

	short m = Month + 12 * a - 2;

	 return (Day + y + (y / 4) - (y / 100) + (y / 400) + ( (31 * m) / 12)) % 7;

}

string NameOfOrderDay(short OrderDay)
{
						 
	string arrDays[7] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

	return arrDays[OrderDay];
}

void PrintResult()
{
	short Year = ReadNumbers("\n Please, Enter A Year?");

	short Month = ReadNumbers("\n Please, Enter A Month?");

	short Day = ReadNumbers("\n Please, Enter A Day?");

	short OrderDay = CulculateTheOrderDay(Year, Month, Day);

	cout << "\n Date      : " << Day << "/" << Month << "/" << Year << endl;
	cout << " Day Order : " << OrderDay << endl;
	cout << " Day Name  : " << NameOfOrderDay(OrderDay) << endl;
}

int main()
{
	
	PrintResult();

	system("pause>0");
	return 0;
}