#include <iostream>
#include <cstdlib>

using namespace std;

enum enGameChoise { stone=1 , paper=2 , scisoor=3};
enum enWinner {player1=1 , computer=2 , draw=3};

struct stRoundInfo
{
    short RoundNumber=0;
    enGameChoise player1choise ;
    enGameChoise computerchise ;
    enWinner winner ;
    string WinnerName="";
    
};

struct stGameResult
{
    short GameRound =0;
    short player1WinTimes=0;
    short computer2WinTimes=0;
    short drawTimes =0;
    enWinner GameWinner ;
    string WinnerName ="";
};

int readrandomnumber(int from , int to)
{
    int num= rand() % (to - from + 1) + from ;
    
    return num ;
}
    
string WinnerName(enWinner winner)
{
    string arrWinnerName[3] = { "player1" , "computer" , "draw"};
    
    return arrWinnerName[winner - 1];
}

enWinner WhoWonTheRound(stRoundInfo RoundInfo)
{
    if(RoundInfo.player1choise == RoundInfo.computerchise)
      return enWinner::draw ;
     
    switch(RoundInfo.player1choise)
    {
      case enGameChoise::stone :
        
         if(RoundInfo.computerchise == enGameChoise::paper)
            return enWinner::computer ;
            break;
         
      case enGameChoise::paper :
        
          if(RoundInfo.computerchise == enGameChoise::scisoor)
            return enWinner::computer ;
            break;
          
      case enGameChoise::scisoor :
      
          if(RoundInfo.computerchise == enGameChoise::stone)
           return enWinner::computer ;
           break;
         
    }
    
     return enWinner::player1 ;
      
}

string ChoiseName(enGameChoise choise)
{
    string arrchiseName[3] = {"stone", "paper" , "scisoor"};
    
    return arrchiseName[choise - 1] ;
    
}

void SetWinnerScreenColor(enWinner Winner)
{
    switch(Winner)
    {
        case enWinner::player1 :
         system("color 2F");
         break ;
         
        case enWinner::computer :
         system("color 4F");
         cout << "\a" ;
         break;
         
        default :
         system("color 6F");
         break;
    }
    
}

void PrintRoundResult(stRoundInfo RoundInfo)
{
    cout << "\n--------------------------Round [" << RoundInfo.RoundNumber << "]--------------------\n\n";
    cout << "  player 1 choise : " << ChoiseName(RoundInfo.player1choise) << endl;
    cout << "  computer choise : " << ChoiseName(RoundInfo.computerchise) << endl;
    cout << "  Round Winner   : [" << RoundInfo.WinnerName << "] \n";
    cout << "------------------------------------------------" <<endl;
    
    SetWinnerScreenColor(RoundInfo.winner);
    
}

enWinner WhoWonTheGame(short player1WinTimes , short computerWinTimes)
{
    if(player1WinTimes > computerWinTimes)
    return enWinner::player1 ;
    
    else if (computerWinTimes > player1WinTimes)
     return enWinner::computer ;
     
    else 
     return enWinner::draw;
}

stGameResult FillGameResult(int gamerounds , short player1WinTimes , short computerWinTimes , short drawTimes)
{
    stGameResult GameResult ;
    
    GameResult.GameRound = gamerounds ;
    GameResult.player1WinTimes = player1WinTimes;
    GameResult.computer2WinTimes = computerWinTimes;
    GameResult.drawTimes = drawTimes ;
    GameResult.GameWinner = WhoWonTheGame(player1WinTimes , computerWinTimes);
    GameResult.WinnerName = WinnerName(GameResult.GameWinner);
    
    return GameResult;
    
}

enGameChoise ReadPlayer1Choise()
{
    short choise = 1;
    
    do
    {
        cout << "\n please enter your choise [1]:stone  [2]:paper  [3]:scisoor ! " << endl;
        cin >> choise ;
        
    }while(choise < 1 || choise > 3);
    
    return (enGameChoise) choise ;
}

enGameChoise GetComputerChoise()
{
    return(enGameChoise) readrandomnumber(1,3) ;
}

stGameResult PlayGame(short houwManyRounds)
{
    stRoundInfo RoundInfo ;
    
    short player1WinTimes=0 , computerWinTimes=0 , drawTimes=0 ;
    
    for(int gameround=1 ; gameround <= houwManyRounds ; gameround++)
    {
        cout << "\n\t round ["<< gameround<<"] begins : \n";
        RoundInfo.RoundNumber = gameround ;
        RoundInfo.player1choise = ReadPlayer1Choise();
        RoundInfo.computerchise = GetComputerChoise();
        RoundInfo.winner = WhoWonTheRound(RoundInfo);
        RoundInfo.WinnerName = WinnerName(RoundInfo.winner);
        
        // increase win/draw counters
        if(RoundInfo.winner == enWinner::player1)
         player1WinTimes++ ;
         
        else if(RoundInfo.winner == enWinner::computer)
          computerWinTimes++;
          
        else
         drawTimes++ ;
         
        PrintRoundResult(RoundInfo);
    }
    
    return FillGameResult(houwManyRounds , player1WinTimes , computerWinTimes , drawTimes);
    
}

string Tabs(short HowmanyTabs)
{
    string t ="";
    
    for(int i=1 ; i< HowmanyTabs ; i++)
    {
        t += "\t" ;
        cout << t ;
    }
    return t ;
}

void ShowGameOverSecreen()
{
    cout << Tabs(2) << "-------------------------------------------------------------------------------------------\n\n";
    cout << Tabs(2) << "                         ++++   G A M E   O V E R    ++++ \n";
    cout << Tabs(2) << "-------------------------------------------------------------------------------------------\n\n";
    
}

void ShowFinalGameResult(stGameResult GameResult)
{
    
    cout << Tabs(2) << "--------------------------------- [GAME RESULT} -----------------------------------\n\n";
    cout << Tabs(2) << " Game Rounds : " << GameResult.GameRound << endl;
    cout << Tabs(2) << " Pmayer 1 won times : " << GameResult.player1WinTimes << endl;
    cout << Tabs(2) << " Computer won times : " << GameResult.computer2WinTimes << endl;
    cout << Tabs(2) << " Draw times : " << GameResult.drawTimes << endl;
    cout << Tabs(2) << " Final winner : " << GameResult.WinnerName << endl;
    cout << Tabs(2) <<"---------------------------------------------------------------------------------------\n";
    
    SetWinnerScreenColor(GameResult.GameWinner);
}

short ReadHowManyRounds()
{
    short gamerounds=0;
    
    do
    {
        cout << "\n please enter how many rounds from 1 to 10 : " << endl;
        cin >> gamerounds;
        
    }while( gamerounds <1 || gamerounds > 10);
    
    return gamerounds;
}

void ResetSecreen()
{
    system("cls");
    system("color 0F");
}

void StartGame()
{
    char playagian = 'y' ;
    
    do
    {
        ResetSecreen();
        stGameResult GameResult = PlayGame(ReadHowManyRounds());
        ShowGameOverSecreen();
        ShowFinalGameResult(GameResult);
        
        cout << "\n \t do want to play again! Y/N : " << endl;
        cin >> playagian ;
        
    }while(playagian =='y' || playagian == 'Y');
}


int main()
{
    srand((unsigned)time(NULL));
    
    StartGame();
    
    
    
    return 0;
}















