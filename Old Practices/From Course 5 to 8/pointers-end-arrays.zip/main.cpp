#include <iostream>

//#include  "mypointerslib.h";

using namespace std;


int main()
{
	int arr[4] = { 10, 20, 21, 23 };
   
	int* ptr = arr;

	cout << "arr adresses using pointers : " << endl << endl;
	cout << ptr << " ";
	cout << ptr + 1 << " ";
	cout << ptr + 2 << " ";
	cout << ptr + 3 << " ";

	printf("\n\n");

	cout << "arr values using pointers : " << endl << endl;
	cout << *ptr << "\t\t\t";
	cout << *(ptr + 1) << "\t\t\t";
	cout << *(ptr + 2) << "\t\t\t";
	cout << *(ptr + 3) << "\t\t\t";


	return 0;
}
