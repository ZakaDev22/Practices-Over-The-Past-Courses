#include <iostream>

using namespace std;


int main() {

	char name[] = "zakaria  ";

	char schoolName[] = "programming advices ";

	printf("my name is : %s \n\n", name);

	printf("your school name is : %s \n\n", schoolName);


	char c = 's';

	printf("the format of one char : %*c \n", 1, c);
	printf("the format of one char : %*c \n", 2, c);
	printf("the format of one char : %*c \n", 3, c);
	printf("the format of one char : %*c \n", 4, c);




	return 0;
}