#include <iostream>

#include <cstdlib>
                                                    //    my solustion #21
using namespace std ;

int readnumber()
{
    int number =0;
    
    cout << " please enter how meny keys do you want " << endl;
    cin >> number ;
    
    return number ;
}

int readrandom(int from , int to)
{
    int randomnumber = rand()%(to - from + 1) + from ;
    
    return randomnumber ;
}

string get_4_letters()
{
    string words="";
    
    for(int i=1 ; i<=4 ; i++)
    {
        words =  char( readrandom(65,90)) ;
        words += char( readrandom(65,90)) ;
        words += char( readrandom(65,90)) ;
        words += char( readrandom(65,90)) ;
    }
    
    return words ;
}

void print_full_key_letters(int number)
{
     int counter =0;
    
    for(int i=1; i<=number ; i++)
    {
        counter++;
        
        cout << "key ["<<counter<<"] : " << get_4_letters() << "-"  << get_4_letters() <<"-" << get_4_letters() << "-" << get_4_letters() <<endl; ;
    }
}

int main()
{
  srand((unsigned)time(NULL));
  
     int number = readnumber();
     
    print_full_key_letters(number) ;
  
    
    return 0;
}





