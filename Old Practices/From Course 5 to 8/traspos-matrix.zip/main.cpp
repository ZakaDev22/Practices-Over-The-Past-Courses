#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{
	short count = 0;

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			count++;
			arr[i][j] = count;
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			cout << setw(3) << arr[i][j] << "   ";
		}
		cout << endl;
	}
}



void TransposMatrix(int arr[3][3] , int arr1[3][3] , short row , short cols)
{
	for (short i = 0; i < row; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr1[i][j] = arr[j][i];
		}
	}
}


int main()
{

	int arr[3][3];

	int arr1[3][3];

	FillMatrixRandom3x3Numbers(arr, 3, 3);


	cout << "\n the following is 3x3 random matrix  \n\n";

	PrintMatrixRandom3x3Numbers(arr, 3, 3);

	cout << "\n\t\n";
	TransposMatrix(arr, arr1, 3, 3);

	cout << "\n the following is 3x3 random matrix to traspos matrix in another array  \n\n";

	PrintMatrixRandom3x3Numbers(arr1, 3, 3);

	return 0;
}
