#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;



string ReplaceStringWords(string s1 , string stringtoReplece ,string replaceTo)
{

	short pos = s1.find(stringtoReplece);

	while (pos != string::npos)
	{
		s1.replace(pos, stringtoReplece.length(), replaceTo);

		pos = s1.find(stringtoReplece);
	}
	

	return s1;
}

int main()
{
	// welcom to jordan , jordan is nice country

	string s1 = mylib::readstring();

	string stringtoReplece = "jordan";

	string replaceTo = "USA";

	cout << "\n string befor Replace : " << s1 << endl;

	cout << "\n string After Replace : ";
	cout << ReplaceStringWords(s1, stringtoReplece, replaceTo) << endl;
	
	


	return 0;
}