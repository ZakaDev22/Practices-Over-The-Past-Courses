#include <iostream>

using namespace std ;

int readpositivnumber(string message)
{
    int number=0 ;
    
   do
   {
       
        cout << message << endl;
        cin >> number ;
       
   }while(number < 0 );
   
    return number ;
    
}

bool isperfectnumber(int number)
{
    int sum=0;
    
    for(int i=1 ; i < number ; i++)
    {
        if( number % i == 0)
         sum += i ;
    }
    
    return number == sum ;
}

void printperfectnumber_from_1_to_n(int number)
{
    
    cout << " all the perfect number of the number " << number << " are " << endl;
    
    for(int i=1 ; i < number ; i++)
    {
        if(isperfectnumber(i))
        {
             cout << i << endl;
        }
         
    }
    
    
}

int main()
{
    printperfectnumber_from_1_to_n(readpositivnumber("please enter a positiv number"));
    
    return 0;
}