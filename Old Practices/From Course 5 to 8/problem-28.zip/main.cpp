#include <iostream>

#include <cstdlib>
                                                //  # my solution
using namespace std ;

int readrandomnumber(int from , int to)
{
    int number = rand() %  (to - from + 1) + from ;
    
    return number ;
}

void read_arrays(int arr[100] ,int arr2[100] , int& arrlength)
{
    cout << "\n enter how meny elimenet do you want : " << endl;
    cin >> arrlength ;
    
     for(int i=0 ; i<arrlength ; i++)
     {
         arr[i] = readrandomnumber(1,100) ;
         arr2[i] = arr[i] ;
     }
     cout << endl;
}

void print_arrays(int arr[100] , int arr2[100] , int arrlength)
{
    cout << "\n array 1 ilements \n";
    for(int i=0 ; i<arrlength ; i++)
     {
         
         cout << arr[i] << " " ;
         
     }
     
     cout << endl;
     
     cout << "\n array 2 ilements \n";
     for(int i=0 ; i<arrlength ; i++)
     {
         
         cout << arr2[i] << " " ;
         
     }
     
}



int main()
{
    
    srand((unsigned)time(NULL)) ;
    
    int arr[100] , arr2[100] , arrlength ;
    
    read_arrays(arr ,arr2 ,arrlength) ;
    
    print_arrays(arr , arr2 , arrlength) ;
    
    return 0;
}




