#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
#include <vector>

#include "MyStringLib.h" 

using namespace std;


vector <string> SplitString(string s1, string delim)
{
	vector <string> vWords;

	short pos = 0;

	string sWord;

	while ((pos = s1.find(delim)) != std::string::npos)
	{
		sWord = s1.substr(0, pos);

		if (sWord != "")
		{
			vWords.push_back(sWord);

		}
		s1.erase(0, pos + delim.length());
	}

	if (sWord != "")
	{
		vWords.push_back(s1);
	}

	return  vWords;
}

string ReversedStringWords( string s1 , string delim)
{
	string s2 = "";

	vector <string> vWords;

	vWords = SplitString(s1, " ");

	vector <string>::iterator iter = vWords.end();

	while (iter != vWords.begin())
	{
		iter--;

		s2 += *iter + delim;
	}

	s2 = s2.substr(0, s2.length() - delim.length()); // Remove last space.

	return s2;
}

int main()
{
	// im zakaria i love programming 

	string s1 = mylib::readstring();

	cout << "\n string befor Reversed : " << s1 << endl;

	cout << "\n string after reversed : ";
	cout << ReversedStringWords(s1, " # ") << endl;

	
	


	return 0;
}