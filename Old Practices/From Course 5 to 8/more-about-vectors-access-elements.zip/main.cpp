#include <iostream>

#include <vector>

using namespace std;



int main()
{
	
	vector <int>  num = { 21,2,23,11 };

	cout << " vectors num ilement using at.() \n " << endl;
	cout << " ilements at index 1 = " << num.at(0) << endl;
	cout << " ilements at index 2 = " << num.at(1) << endl;
	cout << " ilements at index 3 = " << num.at(2) << endl;
	cout << " ilements at index 4 = " << num.at(3) << endl;


	cout << "---------------------------------------\n";

	cout << " vectors num ilement using [] \n " << endl;
	cout << " ilements at index 1 = " << num[0] << endl;
	cout << " ilements at index 3 = " << num[2] << endl;


	return 0;
}

