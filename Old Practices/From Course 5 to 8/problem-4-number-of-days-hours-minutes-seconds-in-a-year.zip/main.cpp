#include <iostream>

#include <string>
#include <vector>
#include <cctype>

using namespace std;

short ReadYear()
{
	short n = 0;

	cout << "\n Please Enter How Many Days In The Year You Want To Tcheck.? ";
	cin >> n;

	return n;
}

bool Is_LeapYear(short Year)
{

	return ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0));
		
}

short NumberOfDaysInOneYear(short Year)
{
	return (Is_LeapYear(Year) ? 366 : 365);
}

short NumberOfHoursInOneYear(short Year)
{
	return NumberOfDaysInOneYear(Year) * 24;
}

int NumberOfMinutesInOneYear(short Year)
{
	return NumberOfHoursInOneYear(Year) * 60;
}

int NumberOfSecondInOneYear(short Year)
{
	return NumberOfMinutesInOneYear(Year) * 60;
}

void PrintResult()
{
	short Year = ReadYear();
    
	cout << "\n Number of Days In year [" << Year << "] is    : " << NumberOfDaysInOneYear(Year) << endl;
	cout << "\n Number of Hours In year [" << Year << "] is   : " << NumberOfHoursInOneYear(Year) << endl;
	cout << "\n Number of Minutes In year [" << Year << "] is : " << NumberOfMinutesInOneYear(Year) << endl;
	cout << "\n Number of Seconds In year [" << Year << "] is : " << NumberOfSecondInOneYear(Year) << endl;

}

int main()
{
	
	PrintResult();

	system("pause>0");
	return 0;
}