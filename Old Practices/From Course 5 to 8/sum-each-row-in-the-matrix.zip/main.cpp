#include <iostream>
#include <cstdlib>
#include <iomanip>

using namespace std;

int  readrandnumber(int from, int to)
{
	//  functionto generate random number

	int reandnum = rand() % (to - from + 1) + from;

	return  reandnum;
}

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr[i][j] = readrandnumber(1, 100);
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			cout << setw(3) << arr[i][j] << "   ";
		}
		cout << endl;
	}
}

void PrintRowSum(int arr[3][3], short rows, short cols)
{
	short sum = 0;

	cout << "\n the following is sum of each row of the matrix\n\n";

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			sum += arr[i][j];
		}
		cout << "row " << i + 1 << " sum : " << sum << endl;
		sum = 0;
	}
}

int main()
{
	srand((unsigned)time(NULL));

	int arr[3][3];

	FillMatrixRandom3x3Numbers(arr, 3, 3);


	cout << "\n the following is 3x3 random matrix \n\n";

	PrintMatrixRandom3x3Numbers(arr, 3, 3);

	PrintRowSum(arr, 3, 3);

	return 0;
}