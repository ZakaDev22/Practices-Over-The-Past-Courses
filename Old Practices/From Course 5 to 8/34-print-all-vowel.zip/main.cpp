#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>

#include "MyStringLib.h" 

using namespace std;


bool IsVowel(char char1)
{
	char1 = tolower(char1);
	
	return (('a' == char1) || ('i' == char1) || ('o' == char1) || ('e' == char1) || ('u' == char1));
}

void PrintAllVowelInString(string s1)
{
	cout << "\n  vowel in the string is = ";

	for (int i = 0; i < s1.length() ; i++)
	{
		if (IsVowel(s1[i]))
		{
			cout << setw(3) << s1[i] << " ";
		}
	}
	cout << endl;
}


int main() {

	//  Programming advices.
	
	string s1 = mylib::readstring();

	  PrintAllVowelInString(s1);


	return 0;
}
