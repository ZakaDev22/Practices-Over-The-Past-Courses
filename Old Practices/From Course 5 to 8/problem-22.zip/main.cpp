#include <iostream>

 #include <string>
                            //  my solution #22
using namespace std ;


int readpositvnumber(string message)
{
    int number =0;
    
    cout << message << endl;
    cin >> number ;
    
    return number ;
}

void get_original_array(int arr[100] , int number)
{
    
    string originalarray ="" ;
    
    
    for(int i=1 ; i <= number ; i++)
    {
        cout << " enter illement ["<<i<<"] : " << endl;
        cin >> arr[i] ;
        
        originalarray = originalarray + to_string(arr[i]) ;
        
    }
     
       int remainder = 0 ;
    
    int num = 0 ;
    cout << "enter the number you want to chack " << endl;
    cin >> num ;
    
    int count = 0 ;
    
    int orriginal = stoi(originalarray) ;
      
    for(int i=1 ; i<=number ; i++)
    {
        remainder = orriginal % 10 ;
         orriginal= orriginal / 10 ;
        
        if(remainder == num)
        {
            count++  ;
        }
    }
    
    cout << " \n\tthe originalarray = " << originalarray << endl;
    
    cout <<  "\n\t" << num << " reapeted " << count << " times " << endl;
    
}


int main()
{
    int number = readpositvnumber("how meny ellements do you want");
    
    int arr[100] ;
    
    get_original_array(arr , number);
    
    return 0;
}



