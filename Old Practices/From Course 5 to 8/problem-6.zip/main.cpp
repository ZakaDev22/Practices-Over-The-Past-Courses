#include <iostream>


using namespace std ;
                                                                //   my solution 
int readpositivenumber(string message)
{
    int number ;
    
    cout << message << endl;
    cin>> number ;
    
    return number ;
}

void printsumofdigits(int number)
{
    int remainder = 0 ;
    
    int sum = 0 ;
    
   do
   {
        remainder = number % 10 ;
        number = number / 10 ;
        
        sum += remainder ;
       
   }while( number > 0 ) ;
    
    
    cout << " \n \n the sum of digits number = " << sum << endl;
    
}

int main()
{
 
   printsumofdigits(readpositivenumber("please enter the number : ")) ;
  

   
   return 0; 
}