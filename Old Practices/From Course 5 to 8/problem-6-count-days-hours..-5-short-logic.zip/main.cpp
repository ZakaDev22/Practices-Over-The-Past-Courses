#include <iostream>

#include <string>
#include <vector>
#include <cctype>

using namespace std;

short ReadYear()
{
	short n = 0;

	cout << "\n Please Enter How Many Days In The Year You Want To Tcheck.? ";
	cin >> n;

	return n;
}

short ReadMonth()
{
	short n = 0;

	cout << "\n Please Enter a Month To Tcheck ? ";
	cin >> n;

	return n;
}

bool Is_LeapYear(short Year)
{ 

	return ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0));
		
}


short NumberOfDaysInOneMonth(short Month, short Year)
{
	if (Month < 1 || Month > 12)
	{
		return 0;
	}
   
	short NumberOfDays[12] = { 31,28,31,30,31,30,31.31,30,31,30,31 };

	return (Month == 2) ? (Is_LeapYear(Year) ? 29 : 28) : NumberOfDays[Month-1];
}


short NumberOfHoursInOneMonth(short Month, short Year)
{
	return NumberOfDaysInOneMonth( Month,  Year) * 24;
}

int NumberOfMenutessInOneMonth(short Month, short Year)
{
	return NumberOfHoursInOneMonth( Month,  Year) * 60;
}

int NumberOfSecondsInOneMonth(short Month, short Year)
{
	return NumberOfMenutessInOneMonth( Month, Year) * 60;
}

void PrintResult()
{
	short Year = ReadYear();

	short Month = ReadMonth();


	cout << "\n Number of Days    In Month [" << Month << "] is : " << NumberOfDaysInOneMonth (Month, Year) << endl;
	cout << "\n Number of Hours   In Month [" << Month << "] is : " << NumberOfHoursInOneMonth(Month, Year) << endl;
	cout << "\n Number of Minutes In Month [" << Month << "] is : " << NumberOfMenutessInOneMonth(Month, Year) << endl;
	cout << "\n Number of Seconds In Month [" << Month << "] is : " << NumberOfSecondsInOneMonth(Month, Year) << endl;

}

int main()
{
	
	PrintResult();

	system("pause>0");
	return 0;
}