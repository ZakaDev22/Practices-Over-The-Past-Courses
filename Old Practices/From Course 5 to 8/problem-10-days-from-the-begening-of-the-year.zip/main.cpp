#include <iostream>

#include <string>
#include <vector>
#include <cctype>
#include <iomanip>

using namespace std;

short ReadNumbers(string message)
{
	short n = 0;

	cout << message;
	cin >> n;

	return n;
}

bool Is_LeapYear(short Year)
{
	return (Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0);
}

short NumberOfDaysInOneMonth(short Month, short Year)
{
	if (Month < 1 || Month > 12)
	{
		return 0;
	}

	short NumberOfDays[13];

	NumberOfDays[0]=0 ,NumberOfDays[1] = 31, NumberOfDays[2]=28;
	NumberOfDays[3]=31, NumberOfDays[4]=30, NumberOfDays[5]=31, NumberOfDays[6]=30;
	NumberOfDays[7]=31, NumberOfDays[8]=31, NumberOfDays[9]=30;
	NumberOfDays[10] = 31, NumberOfDays[11] = 30, NumberOfDays[12]=31;

	return (Month == 2) ? (Is_LeapYear(Year) ? 29 : 28) : NumberOfDays[Month];
}

short SumOfAllDaysFromTheBIgining(short year,short month,short days)
{
	short totalDays = 0;

	for (short i = 1; i <= month - 1; i++)
	{
		totalDays += NumberOfDaysInOneMonth(i, year);
	}

	totalDays += days;

	return totalDays;
}

void PrintResult()
{
	short day = ReadNumbers("\n Please, Enter A Day? ");
	short month = ReadNumbers("\n Please, Enter A Month? ");
	short year = ReadNumbers("\n Please, Enter A Year? ");

	cout << "\n Number Of Days From The begining of the year is : ";
	cout << SumOfAllDaysFromTheBIgining(year, month, day);
}

int main()
{
	
	PrintResult();

	system("pause>0");
 	return 0;
}