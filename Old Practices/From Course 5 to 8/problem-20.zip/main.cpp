
#include <iostream>

#include <cstdlib>

using namespace std;

 enum enrandome { smallletters=1 , capitalletters=2 , spesiallcgaracters=3 , digits=4};


int readnumber(int from , int to)
{
    int randomnumber = rand()% (to - from + 1) + from ;
    
    return randomnumber ;
}


char getradomcharacters(enrandome characterstype)
{
    switch(characterstype)
    {
        case enrandome::smallletters :
        return char(readnumber(97,122));
        break;
        
        case enrandome::capitalletters:
        return char(readnumber(65,90));
        break;
        
        case enrandome::digits :
        return char(readnumber(48,57));
        break;
        
        case enrandome::spesiallcgaracters :
        return char(readnumber(33,47));
        break;
    }
   return characterstype ;
}

int main()
{
    srand((unsigned)time(NULL));
    
    cout << "\n\n\t\t\t" << endl;
    
    cout << "\t\t\t" << getradomcharacters(enrandome::spesiallcgaracters) << endl;
     cout << "\t\t\t" << getradomcharacters(enrandome::smallletters) << endl;
      cout << "\t\t\t" << getradomcharacters(enrandome::capitalletters) << endl;
       cout << "\t\t\t" << getradomcharacters(enrandome::digits) << endl;
    
    
    return 0;
}



