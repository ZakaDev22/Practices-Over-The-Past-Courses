#include <iostream>
#include <cstdlib>

using namespace std;

enum enchoise { add=1 , sub=2 , mul=3 , Div=4};

short choisenumber()
{
    short num =0;
    
    cout << " enter whats your choise add=1 , sub=2 , mul=3 , Div=4 :" << endl;
    cin >> num ;
    
    return num ;
}

enchoise readchoise()
{
    return (enchoise)choisenumber();
}

int readRandom(int from , int to)
{
    int num = rand() % (to - from + 1) + from ;
    return num;
}

short ReadHowMany_Q()
{
    short  Q_Number = 0;
    
    cout << "\n enter how many quetions do you want : " << endl;
    cin >> Q_Number ;
    
    return Q_Number ;
}

void AddNumber()
{
    int number = readRandom(1,10);
    int number2 = readRandom(1,10);
    int answer = 0;
    
    cout << endl<<endl;
    cout << number << endl;
    cout << "     +  " << endl;
    cout << number2 << endl;
    cout << "________________ " << endl;
    cout << " = " <<endl;
    cin >> answer ;
    
    if(answer == number + number2)
    {
        cout << "\n your answer is right :-)\n " << endl;
    }
    else
     cout << "\n your answer is wrong :-( " << " the answer is :  " << number + number2 << endl;
    
}

void SubNumber()
{
    int number = readRandom(1,10);
    int number2 = readRandom(1,10);
    int answer = 0;
    
    cout << endl<<endl;
    cout << number << endl;
    cout << "     -  " << endl;
    cout << number2 << endl;
    cout << "________________ " << endl;
    cout << " = " <<endl;
    cin >> answer ;
    
    if(answer == number - number2)
    {
        cout << "\n your answer is right :-)\n " << endl;
    }
    else
     cout << "\n your answer is wrong :-( " << " the answer is :  " << number - number2 << endl;
    
}

void MulNumber()
{
    int number = readRandom(1,10);
    int number2 = readRandom(1,10);
    int answer = 0;
    
    cout << endl<<endl;
    cout << number << endl;
    cout << "     *  " << endl;
    cout << number2 << endl;
    cout << "________________ " << endl;
    cout << " = " <<endl;
    cin >> answer ;
    
    if(answer == number * number2)
    {
        cout << "\n your answer is right :-)\n " << endl;
    }
    else
     cout << "\n your answer is wrong :-( " << " the answer is :  " << number * number2 << endl;
    
}

void DivNumber()
{
    int number = readRandom(1,10);
    int number2 = readRandom(1,10);
    int answer = 0;
    
    cout << endl<<endl;
    cout << number << endl;
    cout << "     /  " << endl;
    cout << number2 << endl;
    cout << "________________ " << endl;
    cout << " = " <<endl;
    cin >> answer ;
    
    if(answer == number / number2)
    {
        cout << "\n your answer is right :-)\n " << endl;
    }
    else
     cout << "\n your answer is wrong :-( " << " the answer is :  " << number / number2 << endl;
    
}

void WhatIsYourChoise(enchoise choise)
{
    
    switch(readchoise())
    {
        case enchoise::add :
          AddNumber() ;
         break ;
         
        case enchoise::sub :
            SubNumber();
             break ;
             
        case enchoise::mul :
          MulNumber();
          break ;
          
        case enchoise::Div :
          DivNumber() ;
          break ;
          
          default :
           cout << "\n your chois not in case statement ! " << endl;
    }
}

void resetSecreen()
{
    system("cls");
    system("color 0F");
}

void startGame(enchoise choise)
{
    
   short howmanyquistion=0;
   
   char playagian = 'y' ;
    
    do
    {
       resetSecreen();
        
        howmanyquistion = ReadHowMany_Q();
    
    for(int i=1 ; i<= howmanyquistion ;i++)
    {
        WhatIsYourChoise(choise);
    }
        
        cout << "\n \t do want to play again! Y/N : " << endl;
        cin >> playagian ;
        
    }while(playagian =='y' || playagian == 'Y');

}

int main()
{
    srand((unsigned)time(NULL));
    
    enchoise choise ;
    
  startGame(choise);
    
    return 0;
}









