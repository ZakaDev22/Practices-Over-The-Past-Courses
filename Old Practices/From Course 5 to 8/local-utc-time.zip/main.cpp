#pragma warning (disable : 4996) 

#include <iostream>

#include <ctime>

using namespace std;

int main()
{
	time_t t = time(0);

	char* dt = ctime(&t);

	cout << " local time : " << dt << endl;

	tm* internationalTime = gmtime(&t);
	dt = asctime(internationalTime);

	cout << "gm time  : " << dt << endl;

	

	return 0;
} 