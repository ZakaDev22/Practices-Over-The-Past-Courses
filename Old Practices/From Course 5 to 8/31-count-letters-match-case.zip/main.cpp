#include <iostream>
#include <string>
#include <cctype>

#include "MyStringLib.h" 

using namespace std;

string readString()
{
	string s;

	cout << "\n please enter the string you want ! \n";
	getline(cin, s);

	return s;
}

char readchar()
{
	char char1;
	cout << "\n Enter a charater ? \n";
	cin >> char1;

	return char1;
}

short PrintCountCharacterSmall_Capital(string s1, char char1 , bool MatchCase = true)
{
	short count = 0;

	for (int i = 0; i < s1.length(); i++)
	{
		if (MatchCase)
		{
			if (s1[i] == char1)
				count++;
		}

		else
		{
			if (tolower(s1[i]) == tolower(char1))
				count++;
		}
	}

	return count;
}


int main() {

	// Mohammed Abu-Hadhoud Programming ADvices.

	string s1 = readString();
	char char1 = readchar();
	
	cout << "\n letter \'" << char1 << "\' count = " << PrintCountCharacterSmall_Capital(s1, char1) << endl;
	
	cout << "\n letter \'" << char1 << "\' or \'"
	     << mylib::invertCharacters(char1) << "\' count = " 
	     << PrintCountCharacterSmall_Capital(s1, char1,false) << endl;


	return 0;
}