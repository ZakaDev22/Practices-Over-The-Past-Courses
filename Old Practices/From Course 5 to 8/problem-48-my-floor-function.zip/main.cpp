#include <iostream>
#include <cmath>

using namespace std ;

float readnumber()
{
    float number =0 ;
    
    cout << " please enter a number : " << endl;
    cin >> number ;
    
    return number ;
}

int my_Floor_function(int number)
{
    if(number > 0)
     return (int)number;
     
    else
      return (int)number -1 ;
}

int main()
{
    float number = readnumber();
    
    cout << "\n\t my floor function : " << my_Floor_function(number) << endl; 
    
    cout << "\n\t c++ floor function : " << floor(number) << endl; 
  
  
  
    return 0;
}




