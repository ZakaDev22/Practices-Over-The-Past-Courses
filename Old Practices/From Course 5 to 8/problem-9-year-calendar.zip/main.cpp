#include <iostream>

#include <string>
#include <vector>
#include <cctype>
#include <iomanip>

using namespace std;

short ReadNumbers(string message)
{
	short n = 0;

	cout << message;
	cin >> n;

	return n;
}

bool Is_LeapYear(short Year)
{
	return (Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0);
}

short NumberOfDaysInOneMonth(short Month, short Year)
{
	if (Month < 1 || Month > 12)
	{
		return 0;
	}

	short NumberOfDays[13];

	NumberOfDays[0]=0 ,NumberOfDays[1] = 31, NumberOfDays[2]=28;
	NumberOfDays[3]=31, NumberOfDays[4]=30, NumberOfDays[5]=31, NumberOfDays[6]=30;
	NumberOfDays[7]=31, NumberOfDays[8]=31, NumberOfDays[9]=30;
	NumberOfDays[10] = 31, NumberOfDays[11] = 30, NumberOfDays[12]=31;

	return (Month == 2) ? (Is_LeapYear(Year) ? 29 : 28) : NumberOfDays[Month];
}

short CulculateTheOrderDay(short Year, short Month, short Day)
{
	short a = (14 - Month) / 12;

	short y = Year - a;

	short m = Month + (12 * a) - 2;

	return (Day + y + (y / 4) - (y / 100) + (y / 400) + ((31 * m) / 12)) % 7;

}


string MonthOrder(short Month)
{
	string WeekDays[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",  "Aug", "Sep", "Oct","Nov","Dec"};

	return WeekDays[Month-1];
}

void PrintAMonthCalendar(short Month, short Year)
{
	short NUmberOFDays;

	short current = CulculateTheOrderDay(Year, Month, 1);

	NUmberOFDays = NumberOfDaysInOneMonth(Month, Year);

	printf("\n_________________%s_________________\n\n", MonthOrder(Month).c_str());

	printf("  Sun  Mon  Tue  Wed  Thu  Fri  Sat\n");

	short i;
	for (i = 0; i < current; i++)
		printf("     ");

	
	for (short j = 1; j <= NUmberOFDays; j++)
	{
		printf("%5d", j);

		if (++i == 7)
		{
			i = 0;
			printf("\n");
		}
	}
	printf("\n_____________________________________\n\n");
}

void PrintA_YearCalendar(short Year)
{
	printf("\n_____________________________________\n");
	printf("\n            Calendar - %d \n", Year);
	printf("_____________________________________\n");

	for (short i = 1; i <= 12; i++)
	{
		PrintAMonthCalendar(i, Year);
	}
}

void PrintResult()
{
	short Year = ReadNumbers("\n Please, Enter A Year?");

	PrintA_YearCalendar(Year);
}

int main()
{
	
	PrintResult();

	system("pause>0");
	return 0;
}