

#include <iostream>

using namespace std;
                                            // my solution


int readpositivenumber(string message)
{
    int number ;
    
    cout << message << endl;
    cin  >> number ;
    
    return number ;
}

void print_reversed_number(int number)
{
    int remainder = 0;
    int sum = 0;
    
    do
    {
        remainder = number % 10 ;
        number = number / 10 ;
        sum = remainder ;
        
        cout  << sum ;
        
    }while(number > 0);
}

int main()
{
    print_reversed_number(readpositivenumber("please enter a positive number"));

    return 0;
}
