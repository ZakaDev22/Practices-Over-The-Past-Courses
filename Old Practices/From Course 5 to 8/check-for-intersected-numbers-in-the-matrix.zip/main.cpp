#include <iostream>
#include <iomanip>

using namespace std;

void PrintMatrixRandom3x3Numbers(int matrix[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			cout << setw(3) << matrix[i][j] << " ";
		}
		cout << endl;
	}
}

bool checkIstheNumberExistsintheMatrix(int matrix2[3][3], short checknum, short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			if (matrix2[i][j] == checknum)
				return true;
		}
	}
	return false;
}

void printresults(int matrix[3][3], int matrix2[3][3], short rows, short cols)
{
    short number=0;
    
	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
		    number = matrix[i][j];
		    
			if (checkIstheNumberExistsintheMatrix(matrix2, number , rows, cols))
			{
				cout << matrix[i][j] << "  ";
			}
		}
	}
}


int main()
{

	int matrix[3][3] = { {2 ,11,0} , {9,21,5} ,{7,99,44} };
	int matrix2[3][3] = { {5,2,0} , {11,0,9} ,{66,3,6} };


	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix, 3, 3);

	cout << "\n\n Matrix 2 : \n\n";
	PrintMatrixRandom3x3Numbers(matrix2, 3, 3);

	cout << "\n intersected numbers in the matrix  : ";
	printresults(matrix, matrix2, 3, 3) ;

	cout << endl;

	return 0;
}

