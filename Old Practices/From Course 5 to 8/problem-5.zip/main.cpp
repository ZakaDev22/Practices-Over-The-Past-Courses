#include <iostream>


using namespace std ;
                                                            // my teacher solution
int readthenumber(string message)
{
    int number;
    
    cout << message << endl;
    cin >> number ;
    
    return number;
}

void print_pattern_letters(int number)
{
    for(int i= 65 + number - 1 ; i >= 65 ; i-- )
    {
        for(int z=1 ; z <= number - (65 + number - 1 - i) ; z++)
        {
            cout << char(i) ;
        }
        cout << endl;
    }
}


int main()
{
    print_pattern_letters(readthenumber("please enter a positive number"));
    
   return 0; 
}


