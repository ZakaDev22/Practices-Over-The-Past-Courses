#include <iostream>
#include <cmath>

using namespace std ;

int readrounds()
{
    int n=0;
    cout << "\n\n\n\t how many round do you want the number  : \n\n\n " << endl;
    cin >> n;
    
    return n;
}

int readrandomnumber(int from , int to)
{
    int num= rand() % (to - from + 1) + from ;
    
    return num; 
}
    
void how_many_rounds()
{
    int gamerounds = readrounds();
    
     short stone=1 , paper=2 , scisoor=3 ;
    
     short mywin =0 ,  pcwin = 0 , nowinner =0;
    
    short my_chois=0;
    
    short computer_choise = 0 ;
    
    for(int i=1 ; i<=gamerounds ; i++)
    {
         cout << "\n please enter [1]:stone / [2]:paper / [3]:scisoor " << endl;
        cin >> my_chois ;
        
        computer_choise = readrandomnumber(1,3) ;
    
       if(my_chois==paper && computer_choise ==stone)
         mywin++;
         
          else if (my_chois==stone && computer_choise==paper)
          {
               cout << "\a\a";
             pcwin++;
          }
         
         else if (my_chois ==stone && computer_choise ==scisoor)
         mywin++;
         
          else if (my_chois ==scisoor && computer_choise ==stone)
         {
                //system("COLOR 4C"); the coler not found
                
             cout << "\a\a";
             pcwin++;
          }
        else if (my_chois==scisoor && computer_choise ==paper)
         mywin++;
         
           else if (my_chois ==paper && computer_choise ==scisoor)
         {
             cout << "\a\a";
             pcwin++;
          }
         
         else
         {
    
          nowinner++;
         }
    }
    
    cout << "\t\t---------------------------------------[ { GAME OVER } ]-----------------------------------------------\n";
    cout << "\t\t-------------------------------------------------------------------------------------------------------\n";
    cout << endl;
    cout << "\t\t---------------------------------------[ { GAME results } ]--------------------------------------------\n";
    cout << "\t\t-------------------------------------------------------------------------------------------------------\n";
    cout << endl;
    cout <<   "\t\t game rounds : " << gamerounds  << endl;
    cout <<   "\t\t playe 1 won times : " << mywin << endl;
    cout <<   "\t\t computer won times :  " << pcwin << endl;
    cout <<   "\t\t draw times : " << nowinner << endl;
    
    if(mywin > pcwin)
     cout << "\t\t the winner is player 1 :-)" << endl;
     else if (pcwin > mywin)
     cout << "\t\t the computer win :-(" <<endl;
     else
      cout << "\t\t no winner "<<endl;
      
      cout << endl;
      
    cout << "\t\t---------------------------------------[ {*Try Again*} ]-----------------------------------------------\n";
    cout << "\t\t------------------------------------------------------------------------------------------------------\n";

}

bool want_to_play()
{
    short yes=0;
    
     cout << "\n\n\t do you want to play agian yes:[1] / no[0] ! \n\n\n" << endl;
     cin >> yes ;
     
     if(yes)
     return true ;
     
     else
      return false ;
}

/*void reset_screen()
{
    system("cls");
}*/

void start_the_game()
{
    
  do
   {
    //   reset_screen();
       
       how_many_rounds();
       
       cout << endl << endl;
       
   }while(want_to_play()) ;
}



int main()
{
   srand((unsigned)time(NULL));
   
       start_the_game();
       
   
    return 0;
}






