

#include <iostream>

using namespace std;
                                            

int readpositivenumber(string );
int print_frequince_of_n( short , int ) ;
void printresult(int number);



int main()
{
    
      int number = readpositivenumber("please enter a positive number") ;
      
      printresult(number) ;
      
    return 0;
}

int readpositivenumber(string message)
{
    int number ;
    
    cout << message << endl;
    cin  >> number ;
    
    return number ;
}

int print_frequince_of_n( short digittocheck , int number)
{
   
   int remainder = 0 ;
   
   int frequince = 0 ;
   
   while(number > 0)
   {
       remainder = number % 10 ;
       number = number / 10 ;
       
       if(digittocheck == remainder)
       {
           frequince++  ;
       }
   }
   
   return frequince ;
}

void printresult(int number)
{
    for(int i=1 ; i <=9 ; i++)
    {
        short digitsfrequency = 0 ;
        digitsfrequency = print_frequince_of_n(i , number) ;
        
        if(digitsfrequency > 0)
        {
            cout << " digit " << i << " frequince is " << digitsfrequency << " time(s) " << endl;
        }
    }
}

