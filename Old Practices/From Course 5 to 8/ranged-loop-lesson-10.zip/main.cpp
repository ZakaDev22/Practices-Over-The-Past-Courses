#include <iostream>

using namespace std ;


void tryingRagnedLoop()
{
    int arr1[] = {1,2,3};
    
    for(int n : arr1)
    {
        cout <<"\n" "\t"  << n << "  " ;
    }
}
  

int main()
{
   
    tryingRagnedLoop();
    
    return 0;
}