#include <iostream>

#include <vector>

using namespace std;



int main()
{

	vector <int>  num{ 21,2,23,11 };

	vector <int> ::iterator koko;

	for (koko = num.begin(); koko != num.end(); koko++)
	{
		cout << *koko << " ";
	}

	

	return 0;
}

