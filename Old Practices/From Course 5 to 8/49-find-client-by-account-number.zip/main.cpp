#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
#include <fstream>

using namespace std;

const string  clientFilleName = "Clients.txt";

struct stClientData
{
	string accountnumber = "";
	string pincode = "";
	string fullname = "";
	string phone = "";
	double accountbalance = 0;
};


vector <string> SplitString(string s1, string delim)
{
	vector <string> vWords;

	short pos = 0;

	string sWord;

	while ((pos = s1.find(delim)) != std::string::npos)
	{
		sWord = s1.substr(0, pos);

		if (sWord != "")
		{
			vWords.push_back(sWord);

		}
		s1.erase(0, pos + delim.length());
	}

	if (sWord != "")
	{
		vWords.push_back(s1);
	}

	return  vWords;
}

stClientData ConvertClientsDataFromLineToRecord(string stclientrecord, string seperator = "#//#")
{

	stClientData clientdata;

	vector <string> vRecord;

	vRecord = SplitString(stclientrecord, seperator);

	clientdata.accountnumber = vRecord[0];
	clientdata.fullname = vRecord[1];
	clientdata.pincode = vRecord[2];
	clientdata.phone = vRecord[3];
	clientdata.accountbalance = stod(vRecord[4]);


	return clientdata;

}

vector <stClientData> LoedDataFromFilleToVector(string clientFilleName)
{
	fstream Myfille;

	vector <stClientData> vclient;

	Myfille.open(clientFilleName, ios::in); // read mode.

	if (Myfille.is_open())
	{
		string line;
		stClientData client;

		while (getline(Myfille, line))
		{
			client = ConvertClientsDataFromLineToRecord(line);

			vclient.push_back(client);
		}

		Myfille.close();
	}

	return vclient;
}

void PrintClientDataRecord(stClientData clientdata)
{
	cout << "\n";

	cout << "\n   account Name     : " << clientdata.fullname << endl;

	cout << "\n   account Number   : " << clientdata.accountnumber << endl;

	cout << "\n   account Pin Code : " << clientdata.pincode << endl;

	cout << "\n   account Phone    : " << clientdata.phone << endl;

	cout << "\n   account Balance  : " << clientdata.accountbalance << endl;

	cout << "\n\n";

}

bool IsClientNumber_Found(string AccountNumber, stClientData& client)
{
	vector <stClientData> vClient = LoedDataFromFilleToVector(clientFilleName);

	for (stClientData& c : vClient)
	{
		if (c.accountnumber == AccountNumber)
		{
			client = c;

			return true;
		}
	}
	return false;
}

string ReadClientNumber()
{
	string clientNumber = "";
	cout << "\n please anter your account number ? \n" << endl;
	getline(cin, clientNumber);

	return clientNumber;
}

int main()
{
	stClientData client;

	string AccountNumber = ReadClientNumber();

	if (IsClientNumber_Found(AccountNumber, client))
	{
		PrintClientDataRecord(client);
	}
	else
	{
		cout << "\n Client Wiht Account Number (\'" << AccountNumber << "\') Not Found! \n " << endl;
	}

	return 0;
}