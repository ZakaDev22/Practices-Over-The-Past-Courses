#include <iostream>
#include "myinputslib.h";

using namespace std;

using namespace myinputslib;

void MyFunction() {

	//short number = readnumbers();

	 static short number = 1;             // static variabel is like global variabel in c++ level 1 

	cout << " your number = " << number << endl;

	number++;

}

int main() {

	MyFunction();
	MyFunction();
	MyFunction();

	return 0;
}