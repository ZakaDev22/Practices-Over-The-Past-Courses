#include <iostream>
#include <cstdlib>
#include <iomanip>
                                           // My Solution
using namespace std;

short ReadRandomNumbers(short from, short to)
{
	short num = rand() % (to - from + 1) + from;

	return num;
}

void FillMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{
	

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			arr[i][j] = ReadRandomNumbers(1, 10);
		}
	}
}

void PrintMatrixRandom3x3Numbers(int arr[3][3], short rows, short cols)
{

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			printf(" %0*d ", 2, arr[i][j]);
		}
		cout << endl;
	}
}

void PrintOnlytheMiddlerowOfMatrix(int arr[3][3], short rows, short cols)
{
	short middleRow = 1;

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			if (arr[i][j] == arr[middleRow][j])
			{
				printf(" %0*d " , 2, arr[middleRow][j]) ;
			}
		}
		cout << endl;
	}
}

void PrintOnlytheMiddleColsOfMatrix(int arr[3][3], short rows, short cols)
{
	short middleCol = 1;

	for (short i = 0; i < rows; i++)
	{
		for (short j = 0; j < cols; j++)
		{
			if (arr[i][j] == arr[i][middleCol])
			{
				printf(" %0*d ", 2, arr[i][middleCol]);
			}
		}
		cout << endl;
	}
}

int main()
{
	srand((unsigned)time(NULL));

	int arr[3][3];
	

	FillMatrixRandom3x3Numbers(arr, 3, 3);

	cout << "\n\n Matrix 1 : \n\n";
	PrintMatrixRandom3x3Numbers(arr, 3, 3);

	cout << "\n the middle row of the matrix 1  : \n";
	PrintOnlytheMiddlerowOfMatrix(arr, 3, 3);

	cout << "\n the middle col of the matrix 1  : \n";
	PrintOnlytheMiddleColsOfMatrix(arr, 3, 3);

	return 0;
}
