#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

void getDataFromVectorToFile(string filename , vector <string> vFileContent )
{
	fstream MyFile;

	MyFile.open(filename, ios::out); // write mode ;

	if (MyFile.is_open())
	{
		// randed loop 
		for ( string &line : vFileContent)
		{
			if (line != "")
			{
				MyFile << line << endl;
			}

		}
	}

	MyFile.close();
}

int main()
{
	vector <string> vFileContent{ "wolf" , "zakaria" , "caty" , "elfakhar" , "z_Age 21" ,"c_Age 23"};

	getDataFromVectorToFile("MyFile.text", vFileContent);

	return 0;
}
