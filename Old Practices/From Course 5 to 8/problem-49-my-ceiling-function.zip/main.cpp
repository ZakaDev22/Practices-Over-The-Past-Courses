#include <iostream>
#include <cmath>

using namespace std ;

float getfranctionpart(float number)
{
    return number - (int)number ;
}

float readnumber()
{
    float number =0 ;
    
    cout << " please enter a number : " << endl;
    cin >> number ;
    
    return number ;
}

int my_ceil_function(float number)
{
    if(abs(getfranctionpart(number)) > 0)
     {
     if(number > 0)
       return (int)number + 1 ;
     
     else
      return (int)number  ;
    } 
    
    else
      return number ;
     
}

int main()
{
    float number = readnumber();
    
    cout << "\n\t my myceil function : " << my_ceil_function(number) << endl; 
    
    cout << "\n\t c++ ceil function : " << ceil(number) << endl; 
  
  
  
    return 0;
}





