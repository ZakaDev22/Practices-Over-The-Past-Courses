#include <iostream>

#include <cstdlib>

using namespace std ;

int  readrandnumber(int from , int to)
{
    //  functionto generate random number
    
    int reandnum = rand() % (to - from + 1) + from ;
    
    return  reandnum ;
}

int main()
{
    //   srand((unsigned)time(NULL));  this code only once in function main() 
    
       srand((unsigned)time(NULL));
    
    //  cout << rand()  ;  == all int numbers
    
     cout << readrandnumber(1,10)  <<endl;
      cout << readrandnumber(1,10) <<endl ;
       cout << readrandnumber(1,10) <<endl ;
    
    
    return 0;
}