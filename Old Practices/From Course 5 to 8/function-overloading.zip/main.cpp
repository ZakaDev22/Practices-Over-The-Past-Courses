#include <iostream>

#include "mysum.h";

using namespace std;

using namespace mysum;  // i use this code for the first function in the main()

int main() {

	cout << MySum(10, 11) << endl;

	cout << mysum::MySum(10.1, 11.1) << endl;
	cout << mysum::MySum(10, 11, 2) << endl;

	return 0;
}