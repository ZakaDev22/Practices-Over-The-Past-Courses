
#include <iostream>

using namespace std;

int main()
{
      short loonamount ;
      short howmanymounth;
       
        
        
        
        
         cout << "please enter the loon amount : " <<endl; 
         cin >> loonamount; 
          
         cout<< " please enter how many mounth : " << endl;
         cin >>howmanymounth;
           
           cout << "monthly insallment is : " << loonamount/howmanymounth<<endl;
          
          
    return 0;
}