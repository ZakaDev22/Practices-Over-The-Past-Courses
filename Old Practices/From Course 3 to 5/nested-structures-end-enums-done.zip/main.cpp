#include <iostream>
using namespace std;


enum encolor { red , blue , green , yellow };
enum engendor { male , female };
enum enmaritalstatus { single , married };


struct stadresse
{
    string streetname;
    string buildingno;
    string pobox;
    string zipcod;
    
    
};


struct stcontactinfo
{
    string phone;
    string email;
    
    stadresse adresse ;
    
    
};


struct stperson
{
    string firstname;
    string lastname;
    
    stcontactinfo contactinfo ;
    
    encolor color ;
    engendor gendor ;
    enmaritalstatus maritalstatus;
    
};



int main()
{
    
    stperson person1 ;
    
    
    person1.firstname = " zakaria  " ;
    person1.lastname = " elfakhar " ;
    person1.contactinfo.phone = "0762500429";
    person1.contactinfo.email = " hhhahh ";
    person1.contactinfo.adresse.streetname = " db bghala " ;
    person1.contactinfo.adresse.pobox = " 2222 ";
    person1.contactinfo.adresse.buildingno = " 1111 " ;
    person1.contactinfo.adresse.zipcod = " zzz" ;
    person1.gendor = engendor::male ;
    person1.color = encolor::blue ;
    person1.maritalstatus = enmaritalstatus::single ;
    
    
    cout << endl<<endl;
    cout << "*********************************************************\n" ;
    
    cout << " my first name is : " << person1.firstname << endl;
    cout << " my last name : " << person1.lastname << endl;
    cout << " my phone number is : " << person1.contactinfo.phone << endl;
    cout << " my email : " << person1.contactinfo.email << endl;
    cout << " my street adresse : " << person1.contactinfo.adresse.streetname<< endl;
    cout << " my po box  : " << person1.contactinfo.adresse.pobox << endl;
    cout << " my building no : " << person1.contactinfo.adresse.buildingno<<endl;
    cout << " my zip code : " << person1.contactinfo.adresse.zipcod << endl;
    cout << " my gendor : " << person1.gendor << endl ;
    cout << " my fav color : " << person1.color <<endl;
    cout << " my marital status : " << person1.maritalstatus << endl;
    
   cout << "**********************************************************\n" ;
    
    
    
    return 0;
}