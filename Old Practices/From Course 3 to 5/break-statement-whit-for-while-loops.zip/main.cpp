#include <iostream>

using namespace std ;

                            // the important of break statement
int main()             
{
    
    int number[11] = {6,12,20,8,10,22,14,16,18,2,4};
    
    int searchformyage=20 ;
    
    int searchformycatyage=22;
    
    
    for(int i=0 ; i<=11 ; i++)
    {
        cout << " we are in iteration " << i+1 <<endl<<endl;
        
        if(number[i] == 20)
        {
            cout << "\t"<< searchformyage << " found at position " << i+1 << endl;
            
            break;
        }
    }
    
cout << "  *************************************************************\n";
cout << "  *************************************************************\n\n";

     int s=0;
    while(s<=11)
    {
        cout << " we are in iteration " << s+1 << endl;
        s++;
        
        if(number[s]==22)
        {
            cout << "\t" << searchformycatyage << " found in podition " << s+1 << endl;
            
            break;
        }
        
    }
    
    return 0 ;
}