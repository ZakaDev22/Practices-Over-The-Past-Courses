#include <iostream>

using namespace std;


int printnumusingdo_whileloop(int from , int to)
{
   int num ;
   
   do 
   {
       cout << " please enter a number between " << from << " and " << to << endl;
       cin >> num ;
       
   } while(num<from || num>to) ;
   
   return num ;
   
}
int main()
{
    
    cout << " your number " << printnumusingdo_whileloop(20 ,25) << " is valid age " << endl;
 
    
    
    return 0;
}