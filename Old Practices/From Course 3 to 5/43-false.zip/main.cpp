
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    
    float totalseconds ;
    
    cout << "please enter the total seconds : " << endl;
    cin >> totalseconds;
    
    float secondsperday = 24*60*60 ;
    float secondsperhour =60*60 ;
    float secondsperminute = 60 ;
    
    float numberofdays = floor(totalseconds/secondsperday);
    
    
    
    
    
    
    
    
    return 0;
}