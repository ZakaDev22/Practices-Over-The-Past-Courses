#include  <iostream>


using namespace  std;


int main()
{
   int code ;
   
   cout << "please enter your code : " << endl;
   cin >> code ;
   
   if (code==1234)
   {
       
       cout <<" your balance : 7500 " << endl;
       
   }
   
   else 
   {
       
       cout << " wrong pin " << endl;
       
   }
   
   
    
    return 0;
}