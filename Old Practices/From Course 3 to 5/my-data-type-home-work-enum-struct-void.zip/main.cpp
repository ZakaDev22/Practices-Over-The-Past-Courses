#include <iostream>
#include <string>
#include <cmath>

using namespace std ;


enum siyaadresse { myheart = 2 };



void siyaage()
{
     cout << " my siya age is 22 years old :)" << endl;
    
}

void siyaname()
{
     cout << " my siya name is  my caty :) " << endl;

}

struct myfavoratfood
{
    
    string localfood;
    string otherfood;
    siyaadresse adresse;
    
};



struct myfavoratgames
{
       string ongame;
       string ofgame;
       myfavoratfood foodendadress;
       
    
};

  
  
int main()
 {
     myfavoratgames  favorat;
     
    favorat.ongame = "free fire" ;
    favorat.ofgame = "brain traning" ;
    favorat.foodendadress.localfood = " tanjiya ";
    favorat.foodendadress.otherfood = " all the good things :)";
    favorat.foodendadress.adresse = siyaadresse::myheart ;
    
    cout <<endl;
    
    
  cout << "***************************************************************************\n";
      
    cout << "    my favorat online game : " << favorat.ongame << endl;
    cout << "    my favorat ofline game : " << favorat.ofgame << endl;
    cout << "    my favorat local food : " << favorat.foodendadress.localfood<<endl;
    cout << "    my favorat othes food : "<< favorat.foodendadress.otherfood<<endl;
    cout << "    my siya adrees : " << favorat.foodendadress.adresse << endl;
        
      cout << "   "  ;   siyaname() ; // this is void data type  = siya name 
      cout << "   "  ;   siyaage() ;  // this is void data type = siya age 
      
  cout << "******************************************************************************\n";
    
    
    
    
    
    return 0;
}

