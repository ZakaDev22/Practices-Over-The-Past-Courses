
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    float pi = 3.14;
    float a ;
    
    cout << " please enter the number a : " << endl;
    cin >> a ;
    
    cout << " circle area = " << ceil((pi*pow(a,2))/4) << endl ;

    return 0;
}