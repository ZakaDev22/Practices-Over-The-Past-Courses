#include <iostream>
#include <string>

using namespace std ;

enum enpassfail { pass=1 , fail=2};

void read3marks(int& mark1 ,int& mark2 ,int& mark3)
{
    cout << " please enter the first mark : " << endl;
    cin >> mark1 ;
    
    cout << " plaese enter thesecond mark : " << endl;
    cin >> mark2 ;
    
    cout << " please enter the third mark 3 : " << endl;
    cin >> mark3 ;
    
}

int sumof3marks(int mark1 , int mark2 , int mark3)
{
    return mark1 + mark2 + mark3  ;
}

float calculaitaverrag(int mark1 , int mark2 , int mark3)
{
    return  (float)sumof3marks( mark1 ,  mark2 ,  mark3) / 3  ;
}

enpassfail chekmatkpassfail(float averrag)
{
    if (averrag >= 50)
       return enpassfail::pass  ;
       
     else
        return enpassfail::fail  ;
}

void printresults(float averrag)
{
    cout << " \n your averrag is : " << averrag << endl<<endl;
    
    if (chekmatkpassfail(averrag)==enpassfail::pass)
    
        cout << "\n you passed " << endl;
    
    else 
    
       cout << "\n you failed " << endl;
}


int main()
{
        int mark1 , mark2 , mark3 ;
        
        read3marks(mark1 , mark2 , mark3)  ;
        
        
        printresults(calculaitaverrag( mark1 ,  mark2 ,  mark3))  ;
        
            
    return 0;
}