/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{ 
     int number1 ;
     int number2; 
     int number3; 
      
      
    cout<<" pleas enter a number : " <<endl; 
    cin >>number1 ; 
     
     cout << " pleas enter a number : " << endl; 
     cin >>number2; 
     
      cout << " pleas enter a number : " << endl ; 
      cin >>number3 ;
       
        cout <<endl<<endl;
        cout << number1 << "+" <<endl; 
        cout << number2 << "+" <<endl; 
        cout << number3 << endl; 
    cout << "________________________"<<endl; 
    cout << number1+number2+number3 << endl;
     
     
     

    return 0;
}
