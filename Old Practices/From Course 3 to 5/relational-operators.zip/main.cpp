#include <iostream> 
 using namespace std; 
  int main()
  {
       short a ;
       short b ;
       
       
       cout << " please enter number a : " << endl;
       cin >> a ;
       
       cout << " please enter the number b : " << endl;
       cin >> b ;
       
       
       cout << (a==b) << endl;
       cout << (a!=b) << endl;
       cout << (a>b) << endl;
       cout << (a<b )<< endl;
       cout << (a >=b )<<endl;
       cout << (a <=b) << endl;
        
        
        
        
        
        
        
        
        
        return 0;
  }