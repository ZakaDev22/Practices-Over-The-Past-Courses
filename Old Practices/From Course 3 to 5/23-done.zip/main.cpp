
#include <iostream>
#include <cmath>


using namespace std;

int main()
{
    float pi = 3.14 ;
    float a;
    float b;
    float c;
    
    cout << "please enter the number a : " << endl;
    cin >> a;
    
    cout << "please enter the number b : " << endl;
    cin >> b;
    
    cout << "please enter the number c :" << endl;
    cin >> c;
    
    
    float p = (a+b+c)/2 ;
    
    float t = (a*b*c)/(4*sqrt(p*(p-a)*(p-b)*(p-c))) ;
    float T = pi*pow(t,2) ;
    
    
    cout << " circle area = " << T << endl;
    
    cout << " the final result = " << round(T) << endl;
    
    
    

    return 0;
}