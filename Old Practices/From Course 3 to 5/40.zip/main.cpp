
#include <iostream>

using namespace std;

int main()
{
   
   float  billvalue  ; 
     
     
      cout << " enter the bill value : " <<endl;
     cin>>billvalue;
   
     float valuebill = billvalue * 1.1 ; 
     float BILLVALUE = valuebill * 1.16;
   
    
     
     cout << " total bill is :    "  <<  BILLVALUE  << endl;

    return 0;
}

