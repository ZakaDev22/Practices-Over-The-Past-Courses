
#include <iostream>
 #include <cmath>
 
using namespace std;

int main()
{
    float pi = 3.14 ;
    float d ;
    
    
    cout << "please enter the number d : " << endl;
    cin >> d ;
    
    
    cout << "circle area = " << ceil((pi*pow(d,2))/4) << endl;
    
    
    
    
    

    return 0;
}