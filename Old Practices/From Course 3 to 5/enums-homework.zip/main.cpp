#include <iostream>
#include <cmath>
using namespace std;


enum salary { monthlysalary = 5000 , yearlysalary = 60000 };
enum gendor { male = 1 , female = 0 };
enum ismarried { single , married };
enum colors { black = 20 , blue = 2002,  };

struct info1
{
    string name;
    string city;
    string country;
    int age ;
};



int main()
{
    
    info1 information ;
    
    information.name = "mohamad_abou_hadhoud";
    information.city = "amman" ;
    information.country = "jordan";
    information.age = 44 ;
    
    colors myfavoritcolor , myfavoritcolor2;
    
    myfavoritcolor=colors::black ;
    myfavoritcolor2=colors::blue ;
    
    
cout << "************************************************************************"<<endl;
    cout << "   name : " << information.name << endl;
    cout << "   age : " << information.age << endl;
    cout << "   city : " << information.city<<endl;
    cout << "   country : " << information.country<<endl;
    cout << "   monthly salary : " << salary::monthlysalary <<endl;
    cout << "   yearly salary : " << salary::yearlysalary << endl;
    cout << "   my gendor : " << gendor::male << endl;
    cout << "   married : " << ismarried::married<<endl;
    cout << "   my favorit colors : " << myfavoritcolor <<"  \\"<< "\t" << myfavoritcolor2 << endl;
cout << "*************************************************************************" << endl;
    
    
    
    
    return 0;
}