#include <iostream>
#include <string>
#include <cmath>

using namespace std;


float circlearea(float num1 ,float num2 , float pi)
{
    
    return (pi * ((pow(num2,2)/4))) * ((2 * num1 - num2)/(2 * num1 + num2)) ;
}

int main()
{
   
    float num1 , num2 ;
    float pi = 3.14 ;
    
    cout << " please enter num 1 : " << endl;
    cin >> num1 ;
    
    cout << " olease entre num 2 :  "<< endl;
    cin >> num2 ;
    
    
   cout << " circle area = "<< circlearea(num1,num2,pi) << endl;
    
    
    
    
    
    return 0;
}
    