
#include <iostream>

using namespace std;

int main()
{
    string mystring = "abcdefjhigklmnopqrtsuvwxyz" ;
    cout << "the length of my string is : "  << mystring.length() << endl;
    
    cout << mystring[2] << endl; 
    
    string s1 = "10" , s2 ="20";
    
    cout << s1 + s2 << endl;
    
    int s3 = stoi(s1) + stoi(s2)  ;
    
    cout << " sum of s1 end s2 = " << s3 << endl;
    
   
   // (cin >>) end getline( cin , ...)
    string fullname;
    getline(cin , fullname) ;
    cout << fullname <<endl;
    

    return 0;
}