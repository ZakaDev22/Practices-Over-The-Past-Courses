
#include <iostream>

using namespace std;

int main()
{    
    string name = "mohamad abou_hadhoud" ; 
    unsigned short age = 44 ; 
    string city = "amman";  
    string country = "jordan"; 
    float monthlysalary = 5000 ;
    float yearlysalary = 6000 ;
    unsigned char gender = 'm'; 
    bool ismarried = true ; 
      
       
    cout << "*************************************************\n"  ;  
         cout << " name : " << name << endl; 
         cout << " age : " << age << endl; 
         cout << " city : " << city << endl; 
         cout << " country : " << country <<endl; 
         cout << " monthly salary : " << monthlysalary <<endl; 
         cout << " yearly salary : " << yearlysalary << endl; 
         cout << " gender : " << gender << endl; 
         cout << " marriead : " << ismarried << endl;  
    cout << "*****************************************************\n"   ;  
          
           
           
 
  
    return 0;
}