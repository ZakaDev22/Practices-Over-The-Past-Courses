
#include <iostream>
#include <cmath>

using namespace std;

 struct info4
 {
     
     float homenumber;
     string homeadresse;
     
     
 };

 
 struct info3
 {
     string facbook;
     string messanger;
     string instagram;
     float watsapp;
     
 };
 
 
 struct info2
{
    
    float monthlysalary;
    float yearlysalary;
    
};




struct info
 {
     
     string name;
     string city;
     char gender;
     bool ismarried;
     info3 sochmidai;
     info4 boxaddresse;
     
 };


int main()
{
   
   info  information1;
   
   information1.name = "mohamad_abou_hadhoud";
   information1.city = "jordan";
   information1.gender = 'm';
   information1.ismarried = true ;
   
   information1.sochmidai.facbook = " zakaria elfakhar";
   information1.sochmidai.messanger = " zaki elfakhar";
   information1.sochmidai.instagram = "zaka elfakhar ";
   information1.sochmidai.watsapp = 2002;
   
    information1.boxaddresse.homeadresse = "marakech drb albaghala ";
   information1.boxaddresse.homenumber = 98 ;
   
   
   info2 information2;
   
   information2.monthlysalary = 5000;
   information2.yearlysalary = 60000;
   

     
   
   
   cout << endl<<endl;
   cout << "******************************************************************" << endl;
     cout << " name : " << information1.name << endl;
     cout << " city : " << information1.city << endl;
     cout << " monthly salary : " << information2.monthlysalary<<endl;
     cout << " yearly salary : " << information2.yearlysalary << endl;
     cout << " gender : " << information1.gender << endl;
     cout << " married : " << information1.ismarried << endl;
     cout << " facbook : " << information1.sochmidai.facbook << endl;
     cout << " messanger : " <<information1.sochmidai.messanger<<endl;
     cout << "instagram : " <<information1.sochmidai.instagram << endl;
     cout << " watsapp : " <<information1.sochmidai.watsapp << endl;
     cout << " home adresse : " <<information1.boxaddresse.homeadresse << endl;
     cout << " home number : " <<information1.boxaddresse.homenumber << endl;
   cout << "*******************************************************************" << endl;
   
   
   
   
   

    return 0;
}