
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
     
     float number ;
     
     cout << "olease enter the number : " << endl;
     cin >> number;
     
     cout << endl;
     
     cout << pow(number,2) << endl;
     cout << pow(number,3) << endl;
     cout << pow(number,4) << endl;
   
   
   
   return 0;
}