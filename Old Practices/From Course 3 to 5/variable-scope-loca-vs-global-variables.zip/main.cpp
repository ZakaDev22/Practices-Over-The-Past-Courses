#include <iostream>
#include <string>
#include <cmath>
using namespace std;


int x = 600 ;  //  = global variable

void myfunction1()  
{
    int x = 500 ;  // local variable
    
    cout << " the value of x inside my function  = " << x << endl;
    
    
}


int main()   
{
   
   int x = 10 ; // locala variable

   cout << " value of x in this scope = " << x << endl;
   
   myfunction1();
   
   
    ::x = 2002 ;     //globale variable
    
   cout << " globale x = " << ::x << endl;
   
   
   
    return 0;
}