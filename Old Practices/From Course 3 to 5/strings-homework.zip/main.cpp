#include <iostream>
#include <string>

using namespace std;

int main()
{
    string str1 ;
    
    cout << " please enter string 1 : " << endl;
    getline(cin , str1);
    
    string str2 ;
    
    cout << " please enter string 2 : " << endl;
    getline(cin , str2);
    
    string str3 ;
    
    cout << " please enter string 3 : " <<  endl;
    getline(cin,str3) ;
    
cout << "******************************************************\n\n";

  cout << " the length of string is : " << str1.length() << endl;
  cout << "characters at 0,2,5,7 : " << str1[0] << str1[2] << str1[4] << str1[7] << endl;
  
  // concatenating str2 & str3 = 510 
  
  
  cout << "str4 : " << str2 + str3 << endl;
  
  
  int str5 = stoi(str2) * stoi(str3) ;
  
  cout << " str5 : " << str5 << endl;
  
  
  
  
  
  
  
  
  
  
    
    return 0;
}