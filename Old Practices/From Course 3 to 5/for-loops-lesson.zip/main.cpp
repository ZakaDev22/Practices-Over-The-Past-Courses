#include <iostream>

using namespace std;


int main()
{
     for (int z=1 ; z<=5 ; z++)
    {
        cout << "zaka+ssiya  " << z << endl;
    }
     
     
                                       cout << endl;
    
    
    for ( int z=5 ; z>=1 ; z--)
    {
        cout << " ssiya l.z  " << z << endl;
    }
    
    
                                         cout << endl;
                                                    
    for ( int z=1 ; z<=10 ; z=z+2)     
    {
        cout << " zakaria " << z << endl;
    }
   
   
   
    
    return 0 ;
}