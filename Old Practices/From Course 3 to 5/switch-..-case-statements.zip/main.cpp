#include <iostream>

using namespace std ;


int main()
{
    int month ;
    
    cout << " please enter number of your month :" << endl;
    cin >> month ;
    
    
    switch (month)
    {
        case 1 :
            cout << "junary" << endl;
        break ;
        
        case 2 :
            cout << " february" <<endl;
        break ;
        
        case 3 : 
            cout << "march" << endl;
        break ;
        
        case 4 :
            cout << "april" << endl;
        break ;  
        
        case 5 :
            cout << "may" << endl;
        break ;
        
        case 6 :
            cout << "juan" << endl;
        break ;
        
        case 7 :
             cout << "july" << endl;
        break ;
        
        case 8 :
            cout << "august" << endl;
        break ;
        
        case 9 :
           cout << "september" << endl;
        break ;
        
        case 10 : 
             cout << "october" << endl;
        break ;
        
        case 11 :
            cout << "november" << endl;     
        break ;
        
        case 12 :
            cout << "december" <<endl;
        break ;
        
        default :
          cout << " wrong month , please try again" << endl;
        
        
    }
         
    
     
    return 0;
}