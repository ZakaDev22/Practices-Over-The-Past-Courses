#include <iostream>

using namespace std ;


void readarraydata(int arr1[100] , int &length)
{
    cout << " how meny numbers do you want to enter : " << endl;
    cin>>length ;
    
    for(int i=0 ; i<=length-1 ;i++)
    {
        cout << "please enter the number : " << i+1 <<endl;
        cin >> arr1[i];
    }
}

void printarraydata(int arr1[100] , int length)
{
    for (int i=0 ; i<=length-1 ; i++)
    {
        cout << "\t number [" <<i+1<<"] : " <<arr1[i] <<endl;
    }
}

int sumofarraydata(int arr1[100] , int length)
{
    int sum = 0 ;
    
    for(int i=0 ;i<=length-1 ; i++)
    {
        sum+=arr1[i] ;
    }
    
    return sum ;
}

float averageofarraydata(int arr1[100] , int length)
{
    return (float)sumofarraydata(arr1,length)/length ;
}

int main()
{
    int arr1[100] , length=0 ;
    
    readarraydata(arr1 ,length);                 
    printarraydata(arr1,length);
    
    
    // int sum = sumofarraydata(arr1,length);
    // or we can wright << sum << endl;
    // end wright   << sum / length << endl; 
    
                       // or
    
    cout <<"*****************************************************************\n";
    cout <<"*****************************************************************\n";
    
    cout << "\t\t sum = " << sumofarraydata(arr1,length)<< endl; 
    
     cout << "\t\t average = " <<averageofarraydata(arr1,length) << endl;
    
    return 0;
}












