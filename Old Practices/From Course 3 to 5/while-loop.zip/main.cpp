
#include <iostream>

using namespace std;


void print_pin_of_balance()
{
    int atm_pin ;
    cout << " please enter yor atm pin : " << endl;
    cin >> atm_pin ;
    
    
   if (atm_pin==1234)
    {
        
        int i=1 ;
        
         while (i<=1)
    {
         cout <<" \t valid atm_pin , " ;
       cout <<"  your balance is = 7500 $ " << endl;
         i++;
    }
      
    }
     
     else if (atm_pin!=1234)
    {
        
        int i=1 ;
        
         while (i<=3)
    {
        cout <<"please try agian" << endl;
        cin >> atm_pin ;
         i++;
    }
    
    
         cout << " your card is locked ! " << endl;
    } 
    
    
}
 
    
int main()
{
    
  print_pin_of_balance();
    
    
    return 0;
}