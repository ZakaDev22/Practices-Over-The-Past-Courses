#include <iostream>
#include <string>
#include <cmath>

using namespace std;



void mysumprocedure()
{
    int number1 , number2 ;
    
   cout << "please enter th first number : " << endl<<endl ;
   cin >> number1;
    
    cout << "please enter the second number : " << endl<<endl;
   cin >> number2 ;
    
    cout << "*********************************************\n";
    cout << number1 + number2 << endl;
}

int mysumfunction()
{
    int number3 , number4 ;
    
    cout << "please enter the third number : " << endl;
    cin >> number3 ;
    
    cout << " please enter the fourt number : " << endl;
    cin >> number4 ;
    
    return number3+number4;
    
}



int main()
{
    mysumprocedure() ;   // procedur 
    
cout << "____________________________________________________________________\n";

  cout << mysumfunction() - 10 << endl ; // function 
   
    
    
    return 0;
}