#include <iostream>

using namespace std ;

                        //    the deferent betwine (for loop && while loop)
int main()                             
{
    
    cout << " for loop : " << endl;

    for(int i=1 ; i<=5 ; i++)
    {
        cout << i << endl;
    }
    
    cout << " while loop : " << endl;
    
    int j =1 ;
    
    while(j<=5)
    {
        cout << j << endl;
        
        j++ ;
    }
    
    
    return 0;
}