
#include <iostream> 
#include <cmath>

using namespace std;

int main()
{
    
    float pi = 3.14 ;
    float l ;
    
    cout << " please enter the number l : " << endl;
    cin >> l ;
    
    
    cout << " circle area = " << pow(l,2)/(4*pi) << endl;
    
    cout << " the final results = " << floor(pow(l,2)/(4*pi)) << endl;
    
    
    
    return 0;
}