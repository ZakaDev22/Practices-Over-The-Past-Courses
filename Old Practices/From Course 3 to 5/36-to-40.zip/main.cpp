#include <iostream>
                            //  #36
using namespace std ;

enum enoperationtype { add='+' , substract='-' , multiply='*' ,  divide='/'};

float readnumbers(string messege)
{
    int number = 0 ;
    
    cout << messege << endl;
    cin >> number ;
    
    return number ;
}

enoperationtype readoptype()
{
    char ot ;
    
    cout << " please enter ypur op type [ - , / , + , * ] : " << endl;
    cin >> ot ;
    
    return (enoperationtype)ot ;
    
}

float calculate(float num1 , float num2 , enoperationtype optype)
{
    switch (optype)
    {
        case enoperationtype::add :
         return num1 + num2 ;
        case enoperationtype::substract :
         return num1 - num2 ;
        case enoperationtype::multiply :
         return num1 * num2 ;
        case enoperationtype::divide :
         return num1 / num2 ;
       default :
         return num1 + num2 ;
    }
    
}

int main()
{
    float num1 = readnumbers("\n \t plase enter the  first number : ") ;
    float num2 = readnumbers("\n \t plase enter the second number : ") ;
    
    enoperationtype optype = readoptype();
    
    cout << "\n \t result = " << calculate(num1 , num2 , optype) ;
    
    return 0;
}