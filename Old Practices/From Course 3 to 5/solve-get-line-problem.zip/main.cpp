#include <iostream>
#include <string>

using namespace std;

int main()
{
    
    int myage ;
    string myname ;
    string maycountry ;
    string mycity ;
    
    cout << "please enter your age : " << endl;
    cin >> myage ;
    
    cout << "please enter your name  : " << endl;
    // this for solve getline problem (^_^) 
    cin.ignore(1,'\n');   
    // this for solve getline problem (^_^)
    getline(cin , myname);
    
    cout << " please enter your country : " << endl;
    cin >> maycountry ;
    
    cout << "please enter your city : " << endl;
    cin >> mycity;
    
    
    cout << " my name : " << myname << endl;
    cout << " my age : " << myage << endl;
    cout << " my country : " << maycountry << endl;
    cout << " my city : " << mycity << endl;
    
    
    
    
    
    return 0;
}

