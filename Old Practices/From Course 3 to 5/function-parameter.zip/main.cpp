#include <iostream>
#include <string>
#include <cmath>

using namespace std;


void myfunction(int num1) // if we add (&) like this (int &num1) = by reflance
{                        //  if we  dont = by value
    num1 = 7000;
    
    
    cout << " number inside function becom : " << num1 << endl;
    
}

int main()
{
    
    int num1 = 1000 ;
    
    myfunction(num1) ;
    
    cout << " number after cieling becom : " << num1 << endl;
    
    cout << "_____________________________________________________\n";
    
       cout <<  num1 << endl ;
       cout << &num1 << endl ;
    
    
    return 0;
}