
#include <iostream>

using namespace std;

int main()
{
      short mark1; 
      short mark2; 
      short mark3; 
       
       cout << "please enter the first mark : " <<endl; 
       cin >> mark1; 
        
        cout << " please enter the second mark : " <<endl; 
        cin >> mark2; 
         
        cout << " please enter the third mark : " << endl; 
        cin >> mark3; 
         
         cout <<endl;
          cout << " the average of the three marks is = " << (mark1 + mark2 + mark3 )/3 <<endl;

    return 0;
}