
#include <iostream>

using namespace std;

int main()
{
       float totalbill  ; 
       float cashpiad   ;
        
         cout << " total bill : " << endl; 
         cin >> totalbill; 
         
         cout << " cash piad : " << endl; 
         cin >> cashpiad ; 
          
         cout << endl; 
          
         cout << " remainder is : " << cashpiad - totalbill << endl;
        
         
      

    return 0;
}