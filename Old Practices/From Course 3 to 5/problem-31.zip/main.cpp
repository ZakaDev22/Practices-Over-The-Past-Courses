
#include <iostream>

using namespace std;

int main()
{
      short number1 ; 
      
       
       cout << " please enter the irst number : " << endl; 
       cin >> number1 ; 
        
       
         
        cout << endl; 
         
        cout << number1 * number1 << endl; 
        cout << number1 * number1 * number1 << endl; 
        cout << number1 * number1 * number1 * number1 << endl;
           
            
             
             

    return 0;
}