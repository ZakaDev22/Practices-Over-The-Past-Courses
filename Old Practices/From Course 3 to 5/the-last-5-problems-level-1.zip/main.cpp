#include <iostream>

using namespace std;
                                //   #46

void print_letters()
{
    
    for(int i=65 ; i<=90 ; i++)
    {
        cout << char(i) << endl;
    }
}


int main()
{
    print_letters() ;
    
    return 0;
}