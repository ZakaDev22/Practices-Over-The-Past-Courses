#include <iostream>
#include <string>
#include <cmath>


using namespace std;

                        //functions = [int _ float _ double _ string  ... ]
                       //procedures = [ void ]
 
 void myfunction()
 {
     cout << "  my first function , yes bro its the bigining :) " << endl;
     
 }
 
string myfunction2()
{
    
    return "   this is my second function. " ;
}

 int myfunction3()
 {
   int  x = 20 ;
   int  y = 22 ;
   
   return x+y ;
     
 }
 
 float myfunction4()
 {
    float z = 20.2;
    float s = 22.4;
    
    return z+s ;
    
     
 }
 
 
int main()
{
    myfunction();
    
    cout << " my second function : " << myfunction2() << endl;
    
    cout << " my third function : " << myfunction3() << endl;
    
    cout << " my age z + s age = " << myfunction4() << endl;
    
    return 0;
}