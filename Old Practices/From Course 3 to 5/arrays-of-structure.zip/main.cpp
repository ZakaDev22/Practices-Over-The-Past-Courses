#include <iostream>
#include <string>
using namespace std ;



struct strinfo
{
    string firstname ;
    string lastname ;
    int age ;
    string phone ;
    
};

void readestrinfo(strinfo &info)
{
    cout << "please enter your first name : " << endl;
    cin >> info.firstname ;
    
    cout <<" please enter your last name : " << endl;
    cin >> info.lastname ;
    
    cout << "please enter your age : " << endl;
    cin >> info.age ;
    
    cout << " please enter your phone : " << endl;
    cin >> info.phone ;
    
    
}

void printstrinfo(strinfo info)
{
    cout << "************************************************\n\n";
     cout << " first name : " << info.firstname <<endl;
     cout << " last name : " << info.lastname << endl;
     cout << " age : " << info.age << endl;
     cout << " phone : " << info.phone <<endl;
    cout <<"**************************************************\n\n";
    
}

void readpersonsinfo(strinfo person[2])
{
    readestrinfo(person[0]);
    readestrinfo(person[1]);
    
    
}

void printpersonsinfo(strinfo person[2])
{
    
    printstrinfo(person[0]);
    printstrinfo(person[1]);
    
}



int main()
{
   
   strinfo person[2];
   
   readpersonsinfo(person);
   printpersonsinfo(person);
    
    
    return 0;
}
